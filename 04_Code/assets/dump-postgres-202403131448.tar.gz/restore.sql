--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Ubuntu 15.1-1.pgdg20.04+1)
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO '0PJDo6/IddPvRd9OV/ooUU+WeyOQ0irABDZy3qJKwAydtxAImVbFxsbOjhKMWSZeJN5HHUTv/tBe2lHxMEOmpg==';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';
ALTER DATABASE postgres SET "pg_trgm.word_similarity_threshold" TO '0.2';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: custody_type_name; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.custody_type_name AS ENUM (
    'file_owner',
    'viewing',
    'viewing_with_notes'
);


ALTER TYPE public.custody_type_name OWNER TO postgres;

--
-- Name: file_state_name; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.file_state_name AS ENUM (
    'not_viewed_by_custodian',
    'viewed_by_custodian',
    'signed_by_custodian',
    'signed_by_custodian_with_note',
    'closed',
    'personal',
    'signed_viewed_by_custodian'
);


ALTER TYPE public.file_state_name OWNER TO postgres;

--
-- Name: hierarchy_level_name; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.hierarchy_level_name AS ENUM (
    'org',
    'team',
    'thread'
);


ALTER TYPE public.hierarchy_level_name OWNER TO postgres;

--
-- Name: member_level_name; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.member_level_name AS ENUM (
    'admin',
    'member',
    'owner',
    'passive_member'
);


ALTER TYPE public.member_level_name OWNER TO postgres;

--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO postgres;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

    ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
    ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

    REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
    REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

    GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO postgres;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: add_child_post(uuid, text, uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_child_post(given_creator_id uuid, given_content text, given_parent_id uuid, given_forumid uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_post_id uuid:=null;
begin
	insert into public.forum_posts
	(
		creator_id,
		post_content,
		parent_id ,
		is_toplevel ,
		forumid 
	)
	values 
	( 
		given_creator_id,
		given_content,
		given_parent_id,
		false,
		given_forumid
	) returning postid into _new_post_id;
	update public.forum_posts 
	set is_node = false 
	where postid = given_parent_id;
	return _new_post_id;
end;
$$;


ALTER FUNCTION public.add_child_post(given_creator_id uuid, given_content text, given_parent_id uuid, given_forumid uuid) OWNER TO postgres;

--
-- Name: add_file_note(uuid, uuid, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_file_note(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text, given_content text) RETURNS uuid
    LANGUAGE plpgsql
    AS $_$
declare 
	_new_file_noteid uuid:=null;
begin
	execute 
	'insert into
	public.file_notes_signatures (
			fileid,
		    	userid,
			signature,
			signing_key,
			content
	)
	values (
		$1, $2, $3, $4, $5
    	) returning noteid' 
	into _new_file_noteid
    	using 	
    		given_fileid,
		given_signing_userid,
		given_signature,
		given_signing_key,
		given_content ;
	
	execute
	'update public.file_history 
		set added_note_count = added_note_count + 1
		where fileid = $1 and custodian_id = $2'
	using
		given_fileid,
		given_signing_userid;
	return _new_file_noteid; 
end;
$_$;


ALTER FUNCTION public.add_file_note(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text, given_content text) OWNER TO postgres;

--
-- Name: add_forum_thread(uuid, text, text, public.hierarchy_level_name, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_forum_thread(given_creator_id uuid, given_forum_thread_name text, given_forum_subject text, given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_forum_id uuid:=null;
begin
	insert into public.forums
	(
		creator_id,
		forum_thread_name,
		forum_thread_subject,
		hierarchy_level ,
		hierarchy_level_id 
	)
	values 
	( 
		given_creator_id,
		given_forum_thread_name,
		given_forum_subject,
		given_hierarchy_level,
		given_hierarchy_level_id
	) returning forumid into _new_forum_id;
	return _new_forum_id;
end;
$$;


ALTER FUNCTION public.add_forum_thread(given_creator_id uuid, given_forum_thread_name text, given_forum_subject text, given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid) OWNER TO postgres;

--
-- Name: add_notice(uuid, public.hierarchy_level_name, text, text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare
	_noticeid uuid:=null;
	_user record:=null;
	_user_name text:='';
	_hierarchy_name text:='';
begin 
	select ud.username into _user_name from public.user_data ud where ud.userid = given_creator_id;
	insert into 
	public.notices
	(
		creator_id,
		hierarchy_level ,
		hierarchy_level_id ,
		subject ,
		"content" 
	)
	values 
	(
		given_creator_id,
		given_hierarchy_level,
		given_hierarchy_level_id,
		given_subject,
		given_content
	) returning noticeid into _noticeid;
	if (given_hierarchy_level = 'org'::public.hierarchy_level_name ) then 
		select og.org_name into _hierarchy_name from public.organizations og where og.orgid = given_hierarchy_level_id;
		for _user in
			select * from public.user_at_orgs ug where ug.orgid = given_hierarchy_level_id
		loop 
			insert into
		    	public.live_notifications (
	    		src_userid ,
	    		target_userid,
			content ,
			orgid,
			noticeid 
		    	)
	    		values (
	    		given_creator_id,
	    		_user.userid,
	    		_user_name || ' added a notice to the organization: ' || _hierarchy_name,
	    		given_hierarchy_level_id,
	    		_noticeid
	    		);
	    		insert into 
	    		public.user_notices_list (
	    			userid,
	    			noticeid
	    		)
	    		values (
	    			_user.userid,
	    			_noticeid
	    		);
			
		end loop;
		
	elsif (given_hierarchy_level = 'team'::public.hierarchy_level_name) then
		select og.team_name into _hierarchy_name from public.teams og where og.teamid = given_hierarchy_level_id;
		
		for _user in
			select * from public.user_at_teams ug where ug.teamid = given_hierarchy_level_id
		loop 
			insert into
		    	public.live_notifications (
	    		src_userid ,
	    		target_userid,
			content ,
			teamid,
			noticeid
		    	)
		    	values (
	    		given_creator_id,
	    		_user.userid,
	    		_user_name || ' added a notice to the team: ' || _hierarchy_name,
	    		given_hierarchy_level_id,
	    		_noticeid
		    	);
			insert into 
	    		public.user_notices_list (
	    			userid,
	    			noticeid
	    		)
	    		values (
	    			_user.userid,
	    			_noticeid
	    		);
			
		end loop;
	elsif (given_hierarchy_level = 'thread'::public.hierarchy_level_name) then
		select og.threadname into _hierarchy_name from public.threads  og where og.threadid  = given_hierarchy_level_id;
		for _user in
			select * from public.user_at_threads ug where ug.threadid = given_hierarchy_level_id
		loop 
			insert into
	    		public.live_notifications (
	    		src_userid ,
	    		target_userid,
			content ,
			threadid ,
			noticeid
	    		)
	    		values (
	    		given_creator_id,
	    		_user.userid,
	    		_user_name || ' added a notice to the thread: ' || _hierarchy_name,
	    		given_hierarchy_level_id,
	    		_noticeid
		    	);
		    	insert into 
	    		public.user_notices_list (
	    			userid,
	    			noticeid
	    		)
	    		values (
	    			_user.userid,
	    			_noticeid
	    		);
			
		end loop;
	end if;

	return _noticeid;
end;
$$;


ALTER FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid) OWNER TO postgres;

--
-- Name: add_notice(uuid, public.hierarchy_level_name, text, text, uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid, given_fileid uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare
	_noticeid uuid:=null;
	_user record:=null;
	_user_name text:='';
	_hierarchy_name text:='';
begin 
	select ud.username into _user_name from public.user_data ud where ud.userid = given_creator_id;
	insert into 
	public.notices
	(
		creator_id,
		hierarchy_level ,
		hierarchy_level_id ,
		subject ,
		"content" ,
		related_file_id 
	)
	values 
	(
		given_creator_id,
		given_hierarchy_level,
		given_hierarchy_level_id,
		given_subject,
		given_content,
		given_fileid
	) returning noticeid into _noticeid;
	if (given_hierarchy_level = 'org'::public.hierarchy_level_name ) then
		select og.org_name into _hierarchy_name from public.organizations og where og.orgid = given_hierarchy_level_id;
		for _user in
			select * from public.user_at_orgs ug where ug.orgid = given_hierarchy_level_id
		loop 
			insert into
		    	public.live_notifications (
	    		src_userid ,
	    		target_userid,
			content ,
			orgid,
			noticeid 
		    	)
	    		values (
	    		given_creator_id,
	    		_user.userid,
	    		_user_name || ' added a notice to the organization: ' || _hierarchy_name,
	    		given_hierarchy_level_id,
	    		_noticeid
		    	);
			
		end loop;
		
	elsif (given_hierarchy_level = 'team'::public.hierarchy_level_name) then
		select og.team_name into _hierarchy_name from public.teams og where og.teamid  = given_hierarchy_level_id;
		for _user in
			select * from public.user_at_teams ug where ug.teamid = given_hierarchy_level_id
		loop 
			insert into
	    		public.live_notifications (
	    		src_userid ,
	    		target_userid,
			content ,
			teamid,
			noticeid
		    	)
		    	values (
	    		given_creator_id,
	    		_user.userid,
	    		_user_name || ' added a notice to the team: ' || _hierarchy_name,
	    		given_hierarchy_level_id,
	    		_noticeid
	    		);
			
		end loop;
	elsif (given_hierarchy_level = 'thread'::public.hierarchy_level_name) then
		select og.threadname  into _hierarchy_name from public.threads og where og.threadid  = given_hierarchy_level_id;
		for _user in
			select * from public.user_at_threads ug where ug.threadid = given_hierarchy_level_id
		loop 
			insert into
		    	public.live_notifications (
	    		src_userid ,
	    		target_userid,
			content ,
			threadid ,
			noticeid
		    	)
		    	values (
	    		given_creator_id,
	    		_user.userid,
	    		_user_name || ' added a notice to the thread: ' || _hierarchy_name,
	    		given_hierarchy_level_id,
	    		_noticeid
		    	);
				
		end loop;
	end if;

	return _noticeid;
end;
$$;


ALTER FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid, given_fileid uuid) OWNER TO postgres;

--
-- Name: add_notice_file(uuid, uuid, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_notice_file(given_file_ownerid uuid, given_noticeid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_fileid uuid:=null;
begin
	insert into
	public.file_data (
		file_ownerid,
    		current_custodianid,
    		current_state,
    		custody_type,
    		file_url,
    		filename,
    		file_extension,
    		file_mimetype
	)
	values (
		given_file_ownerid,
    		given_file_ownerid,
    		'closed',
    		'file_owner',
    		given_file_url,
    		given_filename,
    		given_file_extension,
    		given_file_mimetype
    	) returning fileid into _new_fileid; 
    
    	update  public.notices 
    	set related_file_id = _new_fileid 
    	where noticeid = given_noticeid;
    
	insert into 
	public.file_history (
		fileid,
		custodian_id 
		 
	)
	values (  
		_new_fileid,
		given_file_ownerid
		
	);
	
	return _new_fileid; 
end;
$$;


ALTER FUNCTION public.add_notice_file(given_file_ownerid uuid, given_noticeid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) OWNER TO postgres;

--
-- Name: add_org_file(uuid, uuid, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_org_file(given_file_ownerid uuid, given_orgid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_fileid uuid:=null;
	_user record:=null;
	_user_name text:='';
	_hierarchy_name text:='';
begin
	select ud.username into _user_name from public.user_data ud where ud.userid = given_file_ownerid;
	
	select og.org_name into _hierarchy_name from public.organizations og where og.orgid = given_orgid;

	insert into
	public.file_data (
		file_ownerid,
    		current_custodianid,
    		current_state,
    		custody_type,
    		file_url,
    		filename,
    		file_extension,
    		file_mimetype
	)
	values (
		given_file_ownerid,
    		given_file_ownerid,
    		'closed',
    		'file_owner',
    		given_file_url,
    		given_filename,
    		given_file_extension,
    		given_file_mimetype
    	) returning fileid into _new_fileid;
	insert into 
	public.file_at_org (
		orgid,
		fileid
	)
	values ( 
		given_orgid,
		_new_fileid
	);
	
	for _user in 
		select * from public.user_at_orgs uat where uat.orgid = given_orgid
	loop
		insert into
	    	public.live_notifications (
	    		src_userid ,
	    		target_userid,
			content ,
			orgid ,
			fileid
	    	)
	    	values (
	    		given_file_ownerid,
	    		_user.userid,
	    		_user_name || ' added a file to the organization: ' || _hierarchy_name,
	    		given_orgid,
			_new_fileid
	    	);
		
	end loop;
	

	return _new_fileid; 
end;
$$;


ALTER FUNCTION public.add_org_file(given_file_ownerid uuid, given_orgid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) OWNER TO postgres;

--
-- Name: add_org_member(uuid, uuid, uuid, public.member_level_name, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_org_member(given_orgid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare 
	_return_val integer:=0;
	_user_name text:='';
	_hierarchy_name text:='';
begin	
	select ud.username into _user_name from public.user_data ud where ud.userid = current_userid;

	select og.org_name into _hierarchy_name from public.organizations og where og.orgid = given_orgid;
	
	if can_add_user_to_org(given_orgid, given_userid) then
		insert into
		public.user_at_orgs (
				userid,
	    			orgid,
	    			user_role,
    				user_post  
		)
		values (
			given_userid , 
			given_orgid,
			given_user_role , 
			given_user_post
	    	);
	   	get diagnostics _return_val = ROW_COUNT;
	    	insert into
	    	public.live_notifications (
	    		target_userid ,
   			src_userid ,
			content ,
			orgid 
	    	)
	    	values (
	    		given_userid,
	    		current_userid,
	    		_user_name || ' added you to the organization: ' || _hierarchy_name,
	    		given_orgid
	    	);
	end if;
	return _return_val; 
end;
$$;


ALTER FUNCTION public.add_org_member(given_orgid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) OWNER TO postgres;

--
-- Name: add_personal_file(uuid, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_personal_file(given_file_ownerid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_fileid uuid:=null;
begin
	insert into
	public.file_data (
		file_ownerid,
    		current_custodianid,
    		current_state,
    		custody_type,
    		file_url,
    		filename,
    		file_extension,
    		file_mimetype
	)
	values (
		given_file_ownerid,
    		given_file_ownerid,
    		'personal',
    		'file_owner',
    		given_file_url,
    		given_filename,
    		given_file_extension,
    		given_file_mimetype
    	) returning fileid into _new_fileid;
	
	return _new_fileid; 
end;
$$;


ALTER FUNCTION public.add_personal_file(given_file_ownerid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) OWNER TO postgres;

--
-- Name: add_personal_file_signature(uuid, uuid, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_personal_file_signature(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_file_signatureid uuid:=null;
begin
	insert into
	public.file_signatures (
			fileid,
		    	signing_userid,
			signature,
			signing_key 
	)
	values (
		given_fileid,
		given_signing_userid,
		given_signature,
		given_signing_key
    	) returning file_signatureid into _new_file_signatureid;
	
	return _new_file_signatureid; 
end;
$$;


ALTER FUNCTION public.add_personal_file_signature(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text) OWNER TO postgres;

--
-- Name: add_publickey_user(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_publickey_user(given_userid uuid, given_publickey text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare 
	_psid integer:=null;
begin
	select count(u.userid) into _psid from public.user_data u where u.userid  = given_userid;
	
	if (_psid = 1) and (given_publickey is not null) then 
		update public.user_data
		set publickey  = given_publickey
		where userid = given_userid;
		insert into public.user_publickey_history(userid, publickey) values(given_userid, given_publickey);
	end if;
	 
	return _psid;
end;
$$;


ALTER FUNCTION public.add_publickey_user(given_userid uuid, given_publickey text) OWNER TO postgres;

--
-- Name: FUNCTION add_publickey_user(given_userid uuid, given_publickey text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.add_publickey_user(given_userid uuid, given_publickey text) IS 'returns 1 if successfully added publickey';


--
-- Name: add_team_file(uuid, uuid, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_team_file(given_file_ownerid uuid, given_teamid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_fileid uuid:=null;
	_user record:=null;
	_parent_orgid uuid:=null;
	_user_name text:='';
	_hierarchy_name text:='';
begin
	select t.parent_orgid into _parent_orgid from public.teams t where t.teamid = given_teamid;
	select ud.username into _user_name from public.user_data ud where ud.userid = given_file_ownerid;
	select og.team_name into _hierarchy_name from public.teams og where og.teamid  = given_teamid;
	insert into
	public.file_data (
		file_ownerid,
    		current_custodianid,
    		current_state,
    		custody_type,
    		file_url,
    		filename,
    		file_extension,
    		file_mimetype
	)
	values (
		given_file_ownerid,
    		given_file_ownerid,
    		'closed',
    		'file_owner',
    		given_file_url,
    		given_filename,
    		given_file_extension,
    		given_file_mimetype
    	) returning fileid into _new_fileid;
	insert into 
	public.file_at_team (
		teamid,
		fileid
	)
	values ( 
		given_teamid,
		_new_fileid
	);
	insert into 
	public.file_at_org (
		fileid,
		orgid
	)
	values (
		_new_fileid,
		_parent_orgid
	);
	
	
	
	for _user in 
		select * from public.user_at_teams uat where uat.teamid = given_teamid
	loop
		insert into
	    	public.live_notifications (
	    		src_userid ,
	    		target_userid,
			content ,
			teamid ,
			fileid
	    	)
	    	values (
	    		given_file_ownerid,
	    		_user.userid,
	    		_user_name || ' added a file to the team: ' || _hierarchy_name,
	    		given_teamid,
			_new_fileid
	    	);
		
	end loop;
	

	return _new_fileid; 
end;
$$;


ALTER FUNCTION public.add_team_file(given_file_ownerid uuid, given_teamid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) OWNER TO postgres;

--
-- Name: add_team_member(uuid, uuid, uuid, public.member_level_name, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_team_member(given_teamid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare 
	_return_val integer:=0;
	_user_name text:='';
	_hierarchy_name text:='';
begin	
	
	select ud.username into _user_name from public.user_data ud where ud.userid = current_userid;
	select og.team_name into _hierarchy_name from public.teams og where og.teamid  = given_teamid;
	
	if can_add_user_to_team(given_teamid, given_userid) then
		insert into
		public.user_at_teams (
				userid,
	    			teamid,
	    			user_role,
    				user_post  
		)
		values (
			given_userid , 
			given_teamid,
			given_user_role , 
			given_user_post
	    	);
	   	get diagnostics _return_val = ROW_COUNT;
	    	insert into
	    	public.live_notifications (
	    		target_userid ,
   			src_userid ,
			content ,
			teamid 
	    	)
	    	values (
	    		given_userid,
	    		current_userid,
	    		_user_name || ' added you to the team: ' || _hierarchy_name,
	    		given_teamid
	    	);
	end if;
	return _return_val; 
end;
$$;


ALTER FUNCTION public.add_team_member(given_teamid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) OWNER TO postgres;

--
-- Name: add_thread_file(uuid, uuid, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_thread_file(given_file_ownerid uuid, given_threadid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_fileid uuid:=null;
	_user record:=null;
	_parent_teamid uuid:=null;
	_parent_orgid uuid:=null;
	_custodian_id uuid:=null;
	_user_name text:='';
	_hierarchy_name text:='';
begin
	select tat.teamid into _parent_teamid from public.thread_at_team tat where tat.threadid = given_threadid and tat.is_parent = true order by tat.created_at asc limit 1;
	select t.parent_orgid into _parent_orgid from public.teams t where t.teamid = _parent_teamid;
	select uat.userid  into _custodian_id from public.threads th join public.user_at_threads uat on th.threadid = uat.threadid  where th.threadid = given_threadid and uat.current_custodian = true;
	
	
	select ud.username into _user_name from public.user_data ud where ud.userid = given_file_ownerid;
	select og.threadname  into _hierarchy_name from public.threads og where og.threadid = given_threadid;

	insert into
	public.file_data (
		file_ownerid,
    		current_custodianid,
    		current_state,
    		custody_type,
    		file_url,
    		filename,
    		file_extension,
    		file_mimetype
	)
	values (
		given_file_ownerid,
    		_custodian_id,
    		'not_viewed_by_custodian',
    		'file_owner',
    		given_file_url,
    		given_filename,
    		given_file_extension,
    		given_file_mimetype
    	) returning fileid into _new_fileid;
	insert into 
	public.file_at_thread (
		threadid,
		fileid
	)
	values ( 
		given_threadid,
		_new_fileid
	);
	insert into 
	public.file_at_org (
		fileid,
		orgid
	)
	values (
		_new_fileid,
		_parent_orgid
	);
	insert into 
	public.file_at_team (
		fileid,
		teamid
	)
	values ( 
		_new_fileid,
		_parent_teamid
	);
	insert into 
	public.file_history (
		fileid,
		custodian_id ,
		threadid 
	)
	values (  
		_new_fileid,
		given_file_ownerid,
		given_threadid
	);
	
	for _user in 
		select * from public.user_at_threads uat where uat.threadid = given_threadid
	loop
		insert into
	    	public.live_notifications (
	    		src_userid ,
	    		target_userid,
			content ,
			threadid ,
			fileid
	    	)
	    	values (
	    		given_file_ownerid,
	    		_user.userid,
	    		_user_name || ' added a file to the thread: ' || _hierarchy_name,
	    		given_threadid,
			_new_fileid
	    	);
		
	end loop;
	

	return _new_fileid; 
end;
$$;


ALTER FUNCTION public.add_thread_file(given_file_ownerid uuid, given_threadid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) OWNER TO postgres;

--
-- Name: add_thread_member(uuid, uuid, uuid, public.member_level_name, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_thread_member(given_threadid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_signing_serial integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare 
	_new_signing_serial integer:=-1;
	_is_member_of_org integer:= 0;
--	_user_org_id uuid:=null;
	_thread_org_id uuid:=null;
	_thread_team_id uuid:= null;
	_is_user_already_in integer:= 0;
	_user_name text:='';
	_hierarchy_name text:='';
begin
--	select uo.orgid into _user_org_id from public.user_at_orgs uo where uo.userid = given_userid;
	
	select tat.teamid into _thread_team_id from public.thread_at_team tat where tat.threadid = given_threadid and tat.is_parent = true limit 1;
	select t.parent_orgid into _thread_org_id from public.teams t where t.teamid = _thread_team_id;

	select ud.username into _user_name from public.user_data ud where ud.userid = current_userid;
	select og.threadname into _hierarchy_name from public.threads og where og.threadid = given_threadid;

	select count(uat.userid) into _is_user_already_in from public.user_at_threads uat where uat.threadid = given_threadid and uat.userid = given_userid;
--	raise notice '% % %', _user_org_id, _thread_org_id, _is_user_already_in;
	if _is_user_already_in = 0 then
		insert into
		public.user_at_threads (
				userid,
	    			threadid,
	    			user_role,
    				signing_serial  
		)
		values (
			given_userid , 
			given_threadid,
			given_user_role , 
			given_signing_serial
	    	) returning signing_serial into _new_signing_serial;
	    	insert into
	    	public.live_notifications (
	    		target_userid ,
   			src_userid ,
			content ,
			threadid ,
			teamid ,
			orgid
	    	)
	    	values (
	    		given_userid,
	    		current_userid,
	    		_user_name || ' added you to the thread: ' || _hierarchy_name,
	    		given_threadid,
	    		_thread_team_id,
	    		_thread_org_id
	    	);
	end if;
	return _new_signing_serial; 
end;
$$;


ALTER FUNCTION public.add_thread_member(given_threadid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_signing_serial integer) OWNER TO postgres;

--
-- Name: add_thread_passive_member(uuid, uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_thread_passive_member(given_threadid uuid, given_userid uuid, current_userid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare 
	_new_signing_serial integer:=-1;
	_is_member_of_org integer:= 0;
	_user_org_id uuid:=null;
	_thread_org_id uuid:=null;
	_thread_team_id uuid:= null;
	_is_user_already_in integer:= 0;
	_user_name text:='';
	_hierarchy_name text:='';
begin
	select uo.orgid into _user_org_id from public.user_at_orgs uo where uo.userid = given_userid;
	select tat.teamid into _thread_team_id from public.thread_at_team tat where tat.threadid = given_threadid and tat.is_parent = true limit 1;
	select t.parent_orgid into _thread_org_id from public.teams t where t.teamid = _thread_team_id;

	select ud.username into _user_name from public.user_data ud where ud.userid = current_userid;
	select og.threadname into _hierarchy_name from public.threads og where og.threadid = given_threadid;

	select count(uat.userid) into _is_user_already_in from public.user_at_threads uat where uat.threadid = given_threadid and uat.userid = given_userid;
	if  _is_user_already_in = 0 then
		insert into
		public.user_at_threads (
				userid,
	    			threadid,
	    			user_role,
    				signing_serial  
		)
		values (
			given_userid , 
			given_threadid,
			'passive_member'::public.member_level_name , 
			-1
	    	) returning signing_serial into _new_signing_serial;
	    	insert into
	    	public.live_notifications (
	    		target_userid ,
   			src_userid ,
			content ,
			threadid ,
			teamid ,
			orgid
	    	)
	    	values (
	    		given_userid,
	    		current_userid,
	    		_user_name || ' added you as a passive member to the thread: ' || _hierarchy_name,
	    		given_threadid,
	    		_thread_team_id,
	    		_thread_org_id
	    	);
	end if;
	return _new_signing_serial; 
end;
$$;


ALTER FUNCTION public.add_thread_passive_member(given_threadid uuid, given_userid uuid, current_userid uuid) OWNER TO postgres;

--
-- Name: add_thread_to_team(uuid, uuid, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_thread_to_team(given_threadid uuid, given_teamid uuid, given_is_parent boolean) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare 
	_count integer:=0;
	_r integer:=0;
begin
	select count(tt.threadid) into _count from public.thread_at_team tt where tt.threadid = given_threadid and tt.teamid = given_teamid;
	if (_count = 0) then 
		insert into public.thread_at_team
		(
			threadid,
			teamid,
			is_parent
		)
		values 
		(
			given_threadid,
			given_teamid,
			given_is_parent
		);	
	end if;
	get diagnostics _r = row_count;
	return _r;
end;
$$;


ALTER FUNCTION public.add_thread_to_team(given_threadid uuid, given_teamid uuid, given_is_parent boolean) OWNER TO postgres;

--
-- Name: add_top_post(uuid, text, text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_top_post(given_creator_id uuid, given_title text, given_content text, given_forumid uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_post_id uuid:=null;
begin
	insert into public.forum_posts
	(
		creator_id,
		post_title ,
		post_content,
		forumid 
	)
	values 
	( 
		given_creator_id,
		given_title,
		given_content,
		given_forumid
	) returning postid into _new_post_id;
	return _new_post_id;
end;
$$;


ALTER FUNCTION public.add_top_post(given_creator_id uuid, given_title text, given_content text, given_forumid uuid) OWNER TO postgres;

--
-- Name: add_user(text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_user(given_username text, given_email text, given_pwd_hash text, given_publickey text, given_pfp_url text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$

declare 
	_new_userid uuid:=null;
begin
	insert into
	public.user_data (
	username ,
	email ,
	pwd_hash  ,
	publickey  ,
	pfp_url  
	)
	values (
	given_username,
	given_email ,
	given_pwd_hash ,
	given_publickey,
	given_pfp_url 
	) returning userid into _new_userid;
	
	return _new_userid; 
end;
$$;


ALTER FUNCTION public.add_user(given_username text, given_email text, given_pwd_hash text, given_publickey text, given_pfp_url text) OWNER TO postgres;

--
-- Name: are_there_notifications(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.are_there_notifications(given_userid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$ 
declare
	_count integer:= 0;
begin
	select count(notificationid) into _count from public.live_notifications where target_userid = given_userid and is_seen = false;
	
	if _count > 0 then
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.are_there_notifications(given_userid uuid) OWNER TO postgres;

--
-- Name: can_add_file_thread(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_add_file_thread(given_userid uuid, given_threadid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare 
	_done boolean:=false;

begin
	select uat.current_custodian into _done from public.user_at_threads uat where uat.userid = given_userid and uat.threadid = given_threadid ;
	if _done is null then 
		_done = false;
	end if;
	return _done;
end;
$$;


ALTER FUNCTION public.can_add_file_thread(given_userid uuid, given_threadid uuid) OWNER TO postgres;

--
-- Name: can_add_user_to_org(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_add_user_to_org(given_orgid uuid, given_userid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$  
declare 
	_count integer:=0;
	
begin
	select count(uat.userid) into _count from public.user_at_orgs uat where uat.orgid  = given_orgid and uat.userid = given_userid;
	if _count = 0 then 
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.can_add_user_to_org(given_orgid uuid, given_userid uuid) OWNER TO postgres;

--
-- Name: can_add_user_to_team(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_add_user_to_team(given_teamid uuid, given_userid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$  
declare 
	_count integer:=0;
	_count2 integer:=0;
	_orgid uuid:=null;
begin
	select t.parent_orgid into _orgid from public.teams t where t.teamid = given_teamid;
	select count(uao.userid) into _count from public.user_at_orgs uao where uao.orgid = _orgid and uao.userid = given_userid;
	select count(uat.userid) into _count2 from public.user_at_teams uat where uat.teamid = given_teamid and uat.userid = given_userid;
	if _count = 1 and _count2 = 0 then 
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.can_add_user_to_team(given_teamid uuid, given_userid uuid) OWNER TO postgres;

--
-- Name: can_add_user_to_thread(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_add_user_to_thread(given_threadid uuid, given_userid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$  
declare 
	_count integer:=0;
	
begin
	select count(uat.userid) into _count from public.user_at_threads uat where uat.threadid = given_threadid and uat.userid = given_userid;
	if _count = 0 then 
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.can_add_user_to_thread(given_threadid uuid, given_userid uuid) OWNER TO postgres;

--
-- Name: can_close_thread(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_close_thread(given_threadid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$ 
declare
	_countfile integer:= 0;
	_count integer:= 0;
	_temp integer:=0;
	_last_user record:= null;
	_current_custodianid uuid:=null;
begin
	select count(fileid) into _countfile from public.file_at_thread where threadid = given_threadid;
	SELECT
            	count(fat.fileid) into _count
	FROM
		public.file_at_thread fat join public.file_data fd on fat.fileid = fd.fileid 
	WHERE
		fat.threadid  = given_threadid
		and
		fd.current_state = 'signed_viewed_by_custodian';
	select (uat.userid) into _current_custodianid from public.user_at_threads uat where uat.threadid = given_threadid and uat.current_custodian = true;
	
	select * into _last_user  from public.user_at_threads uat where  uat.threadid = given_threadid and uat.current_custodian  = true;

	if _count = _countfile  and _last_user.user_role = 'admin'::public.member_level_name then
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.can_close_thread(given_threadid uuid) OWNER TO postgres;

--
-- Name: can_force_forward_thread(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_force_forward_thread(given_threadid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$ 
declare
	_last_sig_serial integer:=0;
begin
	select max(uat.signing_serial) into _last_sig_serial from public.user_at_threads uat where uat.threadid = given_threadid;
	if (
		select max(uat.signing_serial )
		from public.user_at_threads uat 
		where uat.threadid = given_threadid and uat.current_custodian = true
		) <> _last_sig_serial then 
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.can_force_forward_thread(given_threadid uuid) OWNER TO postgres;

--
-- Name: can_forward_thread(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_forward_thread(given_threadid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$ 
declare
	_countfile integer:= 0;
	_count integer:= 0;
	_temp integer:=0;
	_last_user integer:= 0;
	_current_custodianid uuid:=null;
begin
	select count(fileid) into _countfile from public.file_at_thread where threadid = given_threadid;
	SELECT
            	count(fat.fileid) into _count
	FROM
		public.file_at_thread fat join public.file_data fd on fat.fileid = fd.fileid 
	WHERE
		fat.threadid  = given_threadid
		and
		fd.current_state = 'signed_viewed_by_custodian';
	select (uat.userid) into _current_custodianid from public.user_at_threads uat where uat.threadid = given_threadid and uat.current_custodian = true;
	
	select (max(uat.signing_serial)) into _last_user from public.user_at_threads uat where uat.threadid = given_threadid;
	select (uat.signing_serial) into _temp from public.user_at_threads uat where uat.threadid = given_threadid and uat.current_custodian = true;
	
	if _count = _countfile and _last_user <> _temp then
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.can_forward_thread(given_threadid uuid) OWNER TO postgres;

--
-- Name: can_forward_thread2(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_forward_thread2(given_threadid uuid, given_userid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$ 
declare
	_countfile integer:= 0;
	_count integer:= 0;
	_temp integer:=0;
	_curr_user record:=null;
begin
	select count(fileid) into _countfile from public.file_at_thread where threadid = given_threadid;
	SELECT
            	count(fat.fileid) into _count
	FROM
		public.file_at_thread fat join public.file_data fd on fat.fileid = fd.fileid 
	WHERE
		fat.threadid  = given_threadid
		and
		fd.current_state = 'signed_viewed_by_custodian';
	
	select * into _curr_user from public.user_at_threads uat where uat.threadid = given_threadid and uat.userid  = given_userid;

	if _count = _countfile and _curr_user.current_custodian = true then
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.can_forward_thread2(given_threadid uuid, given_userid uuid) OWNER TO postgres;

--
-- Name: can_leave_org(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_leave_org(given_orgid uuid, given_userid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$  
declare 
	_curr_custodian_count integer:=0;
begin
	select count(uat.threadid)  into _curr_custodian_count 
	from public.user_at_threads uat 
	where 
		uat.userid = given_userid 
		and 
		uat.current_custodian = true 
		and 
		uat.threadid in 
			(select th.threadid from public.threads th where th.parent_teamid in 
				(
					select te.teamid  from public.teams te where te.parent_orgid = given_orgid		
				)
			);
	if _curr_custodian_count = 0 then 
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.can_leave_org(given_orgid uuid, given_userid uuid) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: user_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_data (
    userid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    username text,
    email text,
    pwd_hash text,
    publickey text,
    pfp_url text,
    username_search_col tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, COALESCE(username, ''::text))) STORED
);


ALTER TABLE public.user_data OWNER TO postgres;

--
-- Name: can_log_in_user(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_log_in_user(given_email text, given_pwd_hash text) RETURNS public.user_data
    LANGUAGE plpgsql
    AS $$
declare 
	t_user record:=null;
begin 
	select
	*
	into t_user
	from 
	public.user_data u
	where
	u.email  = given_email
	and
	u.pwd_hash = given_pwd_hash;
	if t_user is  null then
		return null;
	else
		return t_user;
	end if;
end;

$$;


ALTER FUNCTION public.can_log_in_user(given_email text, given_pwd_hash text) OWNER TO postgres;

--
-- Name: FUNCTION can_log_in_user(given_email text, given_pwd_hash text); Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON FUNCTION public.can_log_in_user(given_email text, given_pwd_hash text) IS 'returns user_data row if exists, all value null else';


--
-- Name: can_log_in_user_boolean(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_log_in_user_boolean(given_email text, given_pwd_hash text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare 
	_count integer:= 0;
begin 
	select
	count(u.userid)
	into _count
	from 
	public.user_data u
	where
	u.email  = given_email
	and
	u.pwd_hash = given_pwd_hash;
	if _count = 1 then
		return true;
	else
		return false;
	end if;
end;

$$;


ALTER FUNCTION public.can_log_in_user_boolean(given_email text, given_pwd_hash text) OWNER TO postgres;

--
-- Name: can_log_in_user_errorcode(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_log_in_user_errorcode(given_email text, given_pwd_hash text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare 
	_count_total_match integer:=0;
	_count_email_match integer:=0;
begin 
	select
	count(u.userid)
	into _count_total_match
	from 
	public.user_data u
	where
	u.email  = given_email
	and
	u.pwd_hash = given_pwd_hash;
	if _count_total_match = 1 then
		return 0;
	else
		select count(u.userid) into _count_email_match from public.user_data u
		where u.email = given_email;

		if _count_email_match = 1 then
			return 1;
		else
			return 2;
		end if;
	end if;
end;

$$;


ALTER FUNCTION public.can_log_in_user_errorcode(given_email text, given_pwd_hash text) OWNER TO postgres;

--
-- Name: can_signup_user(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.can_signup_user(given_email text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

declare 
	_count integer:=0;
begin
	select count(u.userid) into _count from public.user_data u where u.email  = given_email ;
	raise notice 'cnt = %', _count;
	if _count = 0 then
		
		return true;
	else
		return false;
	end if;
end;

$$;


ALTER FUNCTION public.can_signup_user(given_email text) OWNER TO postgres;

--
-- Name: create_org(text, text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_org(given_orgname text, given_description text, given_userid uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_orgid uuid:=null;
begin
	insert into
	public.organizations (
			org_name,
    			description 
	)
	values (
		given_orgname, 
		given_description
    	) returning orgid into _new_orgid;
    
	insert into 
	public.user_at_orgs (
		userid,
		orgid,
		user_role,
		user_post
	) values ( 
		given_userid,
		_new_orgid,
		'admin',
		'officer'
	);
	return _new_orgid; 
end;
$$;


ALTER FUNCTION public.create_org(given_orgname text, given_description text, given_userid uuid) OWNER TO postgres;

--
-- Name: create_team(uuid, text, text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_team(given_parent_orgid uuid, given_teamname text, given_description text, given_userid uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_teamid uuid:=null;
begin
	insert into
	public.teams (
            parent_orgid,
			team_name,
    		t_description 
	)
	values (
        given_parent_orgid,
		given_teamname, 
		given_description
    	) returning teamid into _new_teamid;
    
	insert into 
	public.user_at_teams (
		userid,
		teamid,
		user_role,
		user_post
	) values ( 
		given_userid,
		_new_teamid,
		'admin',
		'officer'
	);
	return _new_teamid; 
end;
$$;


ALTER FUNCTION public.create_team(given_parent_orgid uuid, given_teamname text, given_description text, given_userid uuid) OWNER TO postgres;

--
-- Name: create_thread(text, uuid, text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_thread(given_threadname text, given_parent_teamid uuid, given_description text, given_userid uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	_new_threadid uuid:=null;
begin
	insert into
	public.threads (
			threadname,
    			description,
    			parent_teamid 
	)
	values (
		given_threadname,  
		given_description,
		given_parent_teamid
    	) returning threadid into _new_threadid;
    
	insert into 
	public.user_at_threads (
		userid,
		threadid,
		user_role,
		signing_serial,
		current_custodian 
	) values ( 
		given_userid,
		_new_threadid,
		'admin',
		1,
		true
	);

	insert into public.thread_at_team 
	(
		threadid,
		teamid,
		is_parent 
	)
	values
	(
		_new_threadid,
		given_parent_teamid,
		true
	);
	return _new_threadid; 
end;
$$;


ALTER FUNCTION public.create_thread(given_threadname text, given_parent_teamid uuid, given_description text, given_userid uuid) OWNER TO postgres;

--
-- Name: edit_passwd(uuid, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.edit_passwd(given_userid uuid, given_new_pwd_hash text, given_old_pwd_hash text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare 
	_c integer:=0;
begin 
	
	update public.user_data 
	set pwd_hash  = given_new_pwd_hash
	where 
		userid = given_userid and pwd_hash = given_old_pwd_hash
	;
	get diagnostics _c = row_count;
	
	if (_c = 1) then 
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.edit_passwd(given_userid uuid, given_new_pwd_hash text, given_old_pwd_hash text) OWNER TO postgres;

--
-- Name: edit_profile(uuid, text, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.edit_profile(given_userid uuid, given_username text, given_email text, given_pwd_hash text, given_pfp_url text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare 
	_c integer:=0;
	_t integer:=0;
begin 
	if given_username is not null then
		update public.user_data 
		set username = given_username
		where userid = given_userid;
		get diagnostics _t = row_count;
		_c := _c + _t;
	end if;
	if given_email is not null then 
		update public.user_data 
		set email  = given_email
		where userid = given_userid;
		get diagnostics _t = row_count;
		_c := _c + _t;
	end if;
	if given_pwd_hash is not null then 
		update public.user_data 
		set pwd_hash  = given_pwd_hash
		where userid = given_userid;
		get diagnostics _t = row_count;
		_c := _c + _t;
	end if;
	if given_pfp_url is not null then
		update public.user_data 
		set pfp_url  = given_pfp_url
		where userid = given_userid;
		get diagnostics _t = row_count;
		_c := _c + _t;
	end if;
	return _c;
end;
$$;


ALTER FUNCTION public.edit_profile(given_userid uuid, given_username text, given_email text, given_pwd_hash text, given_pfp_url text) OWNER TO postgres;

--
-- Name: force_forward_thread(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.force_forward_thread(given_threadid uuid, given_src_userid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$  
declare 
	_updated integer:=0;
	_filedata record:=null;
	_temp integer:= 0;
	_hierarchy_name text:='';
	_target_userid uuid:=null;
	_curr_serial integer:=0;
	_next_serial integer:=0;
begin
	select uat.signing_serial into _curr_serial from public.user_at_threads uat where uat.threadid =given_threadid and uat.current_custodian = true;
	_next_serial := _curr_serial + 1;

	select into _target_userid from public.user_at_threads uat where uat.signing_serial = _next_serial; 
	
	select og.threadname into _hierarchy_name from public.threads og where og.threadid = given_threadid;
	
	update public.user_at_threads  
	set current_custodian = false
	where userid = given_src_userid;
		
	update public.user_at_threads  
	set current_custodian = true
	where userid = _target_userid;
	
	for _filedata in 
		select * 
		from public.file_at_thread fat join public.file_data fd on fd.fileid =fat.fileid  
		where fat.threadid = given_threadid 
	loop 
		insert into  public.file_history (fileid, custodian_id, threadid)
		values  (_filedata.fileid, _target_userid, given_threadid);
		
		
		
		update public.file_data 
		set current_state = 'not_viewed_by_custodian'::file_state_name, 
			current_custodianid = _target_userid
		where file_data.fileid = _filedata.fileid;
	
		get DIAGNOSTICS _temp = ROW_COUNT;
		_updated = _updated + _temp;
		
		if _filedata.file_ownerid <> _target_userid then
			update public.file_data set custody_type = 'viewing'::custody_type_name where fileid = _filedata.fileid;
		end if;
	
	
	end loop;
	insert into
	    	public.live_notifications (
	    		target_userid ,
   			src_userid ,
			content ,
			threadid 
	    	)
	values (
	    		_target_userid,
	    		given_src_userid,
	    		'You have been made current custodian of the thread: ' || _hierarchy_name,
	    		given_threadid
	    	);
	
	return _updated;
end;
$$;


ALTER FUNCTION public.force_forward_thread(given_threadid uuid, given_src_userid uuid) OWNER TO postgres;

--
-- Name: forward_thread(uuid, uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.forward_thread(given_threadid uuid, given_src_userid uuid, given_target_userid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$  
declare 
	_updated integer:=0;
	_filedata record:=null;
	_temp integer:= 0;
	_hierarchy_name text:='';
begin
	
	select og.threadname into _hierarchy_name from public.threads og where og.threadid = given_threadid;
	
	update public.user_at_threads  
	set current_custodian = false
	where userid = given_src_userid;
		
	update public.user_at_threads  
	set current_custodian = true
	where userid = given_target_userid;
	
	for _filedata in 
		select * 
		from public.file_at_thread fat join public.file_data fd on fd.fileid =fat.fileid  
		where fat.threadid = given_threadid 
	loop 
		insert into  public.file_history (fileid, custodian_id, threadid)
		values  (_filedata.fileid, given_target_userid, given_threadid);
		
		
		
		update public.file_data 
		set current_state = 'not_viewed_by_custodian'::file_state_name, 
			current_custodianid = given_target_userid
		where file_data.fileid = _filedata.fileid;
	
		get DIAGNOSTICS _temp = ROW_COUNT;
		_updated = _updated + _temp;
		
		if _filedata.file_ownerid <> given_target_userid then
			update public.file_data set custody_type = 'viewing'::custody_type_name where fileid = _filedata.fileid;
		end if;
	
	
	end loop;
	insert into
	    	public.live_notifications (
	    		target_userid ,
   			src_userid ,
			content ,
			threadid 
	    	)
	values (
	    		given_target_userid,
	    		given_src_userid,
	    		'You have been made current custodian of the thread: ' || _hierarchy_name,
	    		given_threadid
	    	);
	
	return _updated;
end;
$$;


ALTER FUNCTION public.forward_thread(given_threadid uuid, given_src_userid uuid, given_target_userid uuid) OWNER TO postgres;

--
-- Name: forward_thread_file(uuid, uuid, uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.forward_thread_file(given_threadid uuid, given_fileid uuid, given_src_userid uuid, given_target_userid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$  
declare 
	_updated integer:=0;
begin
	insert into  public.file_history (fileid, custodian_id, threadid)
	values  (given_fileid, given_target_userid, given_threadid);
	get DIAGNOSTICS _updated = ROW_COUNT;
	update public.file_data set current_state = 'not_viewed_by_custodian'::file_state_name where file_data.fileid = given_fileid;
	return _updated;
end;
$$;


ALTER FUNCTION public.forward_thread_file(given_threadid uuid, given_fileid uuid, given_src_userid uuid, given_target_userid uuid) OWNER TO postgres;

--
-- Name: get_all_orgs(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_all_orgs() RETURNS TABLE(f_orgid uuid, f_created_at timestamp with time zone, f_org_name text, f_description text)
    LANGUAGE plpgsql
    AS $$

begin
	return query select 
	o.orgid ,
	o.created_at ,
	o.org_name ,
	o.description 
	from public.organizations o ;
end;
$$;


ALTER FUNCTION public.get_all_orgs() OWNER TO postgres;

--
-- Name: get_current_signing_serial(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_current_signing_serial(given_threadid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
	_done integer:=0;
	
begin
	select max(uat.signing_serial ) into _done from public.user_at_threads uat where uat.threadid = given_threadid;
	return _done;
end;
$$;


ALTER FUNCTION public.get_current_signing_serial(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_file_data_39(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_file_data_39(owner_id uuid, type text) RETURNS TABLE(__filename text, __date timestamp with time zone, __id uuid)
    LANGUAGE plpgsql
    AS $$
  begin
    return query select filename, created_at, fileid
    from file_data
    where file_ownerid = owner_id and file_extension = type;
  end;
$$;


ALTER FUNCTION public.get_file_data_39(owner_id uuid, type text) OWNER TO postgres;

--
-- Name: get_file_history_fileid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_file_history_fileid(given_fileid uuid) RETURNS TABLE(f_fileid uuid, f_start_at timestamp with time zone, f_custodian_id uuid, f_threadid uuid, f_added_note_count bigint, f_username text, f_publickey text, f_email text)
    LANGUAGE plpgsql
    AS $$

begin 
	return query select
		fh.fileid ,
		fh.start_at ,
		fh.custodian_id ,
		fh.threadid ,
		fh.added_note_count ,
		ud.username ,
		ud.publickey ,
		ud.email 
	from 
	public.file_history fh join public.user_data ud  on fh.custodian_id = ud.userid 
	where
	fh.fileid = given_fileid
	order by
	fh.start_at desc;
end;
$$;


ALTER FUNCTION public.get_file_history_fileid(given_fileid uuid) OWNER TO postgres;

--
-- Name: get_file_signatures_fileid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_file_signatures_fileid(given_fileid uuid) RETURNS TABLE(f_file_signatureid uuid, f_created_at timestamp with time zone, f_fileid uuid, f_signing_userid uuid, f_signature text, f_note text, f_signature_serial integer, f_signing_key text, f_signing_username text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	
            		fsig.file_signatureid ,
            		fsig.created_at ,
            		fsig.fileid,
            		fsig.signing_userid,
            		fsig.signature,
            		fsig.note,
            		fsig.signature_serial,
            		fsig.signing_key,
            		ud.username
            	
	FROM
		public.file_signatures fsig join public.user_data ud
	on 
		fsig.signing_userid  = ud.userid 
	WHERE
		fsig.fileid  = given_fileid
	order by fsig.created_at desc;
end;
$$;


ALTER FUNCTION public.get_file_signatures_fileid(given_fileid uuid) OWNER TO postgres;

--
-- Name: get_forum_metadata(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_forum_metadata(given_forumid uuid) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare 
	_r record:=null;
begin 
	select 
	f.forumid ,
	f.created_at ,
	f.forum_thread_name ,
	f.creator_id ,
	f.forum_thread_subject ,
	f.hierarchy_level ,
	f.hierarchy_level_id ,
	ud.username ,
	ud.email ,
	ud.publickey ,
	ud.pfp_url ,
	ud.created_at as joined_at
	into _r 
	from public.forums f join public.user_data ud on f.creator_id = ud.userid 
	where f.forumid = given_forumid;
	return _r;
	
end;

$$;


ALTER FUNCTION public.get_forum_metadata(given_forumid uuid) OWNER TO postgres;

--
-- Name: get_forum_top_level_posts(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_forum_top_level_posts(given_forumid uuid) RETURNS TABLE(f_postid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_creator_name text, f_creator_pubkey text, f_creator_mail text, f_pfp_url text, f_joined_at timestamp with time zone, f_post_title text, f_content text)
    LANGUAGE plpgsql
    AS $$

begin 
	return query select 
	fp.postid , fp.created_at , fp.creator_id , ud.username , ud.publickey , ud.email , ud.pfp_url , ud.created_at , fp.post_title , fp.post_content 
	from public.forum_posts fp join public.user_data ud on fp.creator_id = ud.userid where fp.forumid = given_forumid and fp.is_toplevel = true order by fp.created_at desc;
end;

$$;


ALTER FUNCTION public.get_forum_top_level_posts(given_forumid uuid) OWNER TO postgres;

--
-- Name: get_hierarchy_all_forum_metadata(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_hierarchy_all_forum_metadata(given_uid uuid) RETURNS TABLE(f_forumid uuid, f_created_at timestamp with time zone, f_forum_thread_name text, f_forum_thread_subject text, f_hierarchy_level public.hierarchy_level_name, f_hierarchy_level_id uuid, f_creator_id uuid, f_joined_at timestamp with time zone, f_username text, f_email text, f_pubkey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$
declare 
	_r record:=null;
	_res record:=null;
	_t record:=null;
begin 

	create table temp_table(f_forumid uuid, f_created_at timestamptz, f_forum_thread_name text, f_forum_thread_subject text, f_hierarchy_level public.hierarchy_level_name, f_hierarchy_level_id uuid, f_creator_id uuid, f_joined_at timestamptz, f_username text, f_email text, f_pubkey text, f_pfp_url text);
	for _r in 
		select * from public.forums f where f.hierarchy_level_id = given_uid
		loop 
			select * into _t from public.user_data ud where ud.userid = _r.creator_id;
		
			insert into temp_table
			values 
			( 
				_r.forumid,
				_r.created_at,
				_r.forum_thread_name,
				_r.forum_thread_subject,
				_r.hierarchy_level,
				_r.hierarchy_level_id,
				_t.userid,
				_t.created_at,
				_t.username,
				_t.email,
				_t.publickey,
				_t.pfp_url
			);
			
		end loop;
	return query select * from temp_table;
	drop table if exists temp_table;
end;

$$;


ALTER FUNCTION public.get_hierarchy_all_forum_metadata(given_uid uuid) OWNER TO postgres;

--
-- Name: get_notice_recipient_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_notice_recipient_list(given_noticeid uuid) RETURNS TABLE(f_sent_at timestamp with time zone, f_userid uuid, f_noticeid uuid, f_is_seen boolean, f_created_at timestamp with time zone, f_username text, f_email text, f_publickey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	uat.created_at ,
        	uat.userid,
        	uat.noticeid  ,
        	uat.is_seen ,
        	ud.created_at,
		ud.username,
		ud.email,
		ud.publickey,
		ud.pfp_url
	FROM
		public.user_data ud join public.user_notices_list uat on ud.userid = uat.userid 
	WHERE
		uat.noticeid = given_noticeid;
end;
$$;


ALTER FUNCTION public.get_notice_recipient_list(given_noticeid uuid) OWNER TO postgres;

--
-- Name: get_notice_scope_entity_details(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_notice_scope_entity_details(given_noticeid uuid) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare 
	_result record:=null;
	_notice record:=null;
begin
	select * into _notice from public.notices n where n.noticeid  = given_noticeid;
	if (_notice.hierarchy_level = 'org'::public.hierarchy_level_name) then 
		select * into _result from public.organizations th where th.orgid = _notice.hierarchy_level_id;
	elsif (_notice.hierarchy_level = 'team'::public.hierarchy_level_name) then 
		select * into _result from public.teams th where th.teamid = _notice.hierarchy_level_id;
	else 
		select * into _result from public.threads th where th.threadid = _notice.hierarchy_level_id;
	end if;
	return _result;
end;
$$;


ALTER FUNCTION public.get_notice_scope_entity_details(given_noticeid uuid) OWNER TO postgres;

--
-- Name: get_notice_seen_recipient_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_notice_seen_recipient_list(given_noticeid uuid) RETURNS TABLE(f_sent_at timestamp with time zone, f_userid uuid, f_noticeid uuid, f_is_seen boolean, f_created_at timestamp with time zone, f_username text, f_email text, f_publickey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	uat.created_at ,
        	uat.userid,
        	uat.noticeid  ,
        	uat.is_seen ,
        	ud.created_at,
		ud.username,
		ud.email,
		ud.publickey,
		ud.pfp_url
	FROM
		public.user_data ud join public.user_notices_list uat on ud.userid = uat.userid 
	WHERE
		uat.noticeid = given_noticeid
	and 
		uat.is_seen = true;
end;
$$;


ALTER FUNCTION public.get_notice_seen_recipient_list(given_noticeid uuid) OWNER TO postgres;

--
-- Name: get_notice_unseen_recipient_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_notice_unseen_recipient_list(given_noticeid uuid) RETURNS TABLE(f_sent_at timestamp with time zone, f_userid uuid, f_noticeid uuid, f_is_seen boolean, f_created_at timestamp with time zone, f_username text, f_email text, f_publickey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	uat.created_at ,
        	uat.userid,
        	uat.noticeid  ,
        	uat.is_seen ,
        	ud.created_at,
		ud.username,
		ud.email,
		ud.publickey,
		ud.pfp_url
	FROM
		public.user_data ud join public.user_notices_list uat on ud.userid = uat.userid 
	WHERE
		uat.noticeid = given_noticeid
	and 
		uat.is_seen = false;
end;
$$;


ALTER FUNCTION public.get_notice_unseen_recipient_list(given_noticeid uuid) OWNER TO postgres;

--
-- Name: get_noticedetails(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_noticedetails(given_noticeid uuid) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare 
	_result record:=null;
	_notice record:=null;
	_user record:=null;
	_hierarchy_name text:='kkk ami';
begin
	create table temp_table2(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text null, f_content text null, f_hierarchy_level_id uuid null, f_related_file_id uuid, f_creator_name text, f_email text, f_pubkey text, f_pfp_url text, f_hierarchy_name text);
	select 
		*
	into 
		_notice
	from 
		public.notices n
	where 
		n.noticeid  = given_noticeid;
	
	select
	*
	into _user
	from 
	public.user_data u
	where
	u.userid = _notice.creator_id;

	
	if (_notice.hierarchy_level = 'org'::public.hierarchy_level_name) then 
		raise notice 'org';
		select o.org_name into _hierarchy_name from public.organizations o where o.orgid = _notice.hierarchy_level_id;
	elsif (_notice.hierarchy_level = 'team'::public.hierarchy_level_name) then
		raise notice 'team';
		select o.team_name into _hierarchy_name from public.teams o where o.teamid = _notice.hierarchy_level_id;
	elsif (_notice.hierarchy_level = 'thread'::public.hierarchy_level_name) then
		
		select o.threadname into _hierarchy_name from public.threads o where o.threadid = _notice.hierarchy_level_id;
--		raise notice '%', _hierarchy_name;
	end if;
	
	insert into temp_table2
	values 
	(
		_notice.noticeid,
		_notice.created_at,
		_notice.creator_id,
		_notice.hierarchy_level,
		_notice.subject,
		_notice.content,
		_notice.hierarchy_level_id,
		_notice.related_file_id,
		_user.username,
		_user.email,
		_user.publickey,
		_user.pfp_url,
		_hierarchy_name
	);
	select * into _result from temp_table2 tt where tt.f_noticeid = given_noticeid;
	drop table if exists temp_table2;
	return _result;
end;
$$;


ALTER FUNCTION public.get_noticedetails(given_noticeid uuid) OWNER TO postgres;

--
-- Name: get_org_active_threads(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_active_threads(given_orgid uuid) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text)
    LANGUAGE plpgsql
    AS $$
declare
	_team record:=null;
	_thread record:=null;
begin	
	create table res (f_threadid uuid, f_created_at timestamptz, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text);
	
	for _team in
		select t.teamid from public.teams t where t.parent_orgid = given_orgid
	loop 
		for _thread in
			select * from public.threads t2 join public.thread_at_team tat on t2.threadid = tat.threadid where tat.teamid = _team.teamid and t2.is_active = true
		loop
			insert into res 
			values 
			(
				_thread.threadid,
				_thread.created_at,
				_thread.threadname,
				_thread.parent_teamid,
				_thread.description,
				_thread.is_active,
				_thread.closing_comment
			);
			
		end loop;
		
		
	end loop;
	
	return query select * from res;
	drop table if exists res;
end;
$$;


ALTER FUNCTION public.get_org_active_threads(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_addable_member_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_addable_member_list(given_orgid uuid) RETURNS TABLE(f_userid uuid, f_created_at timestamp with time zone, f_username text, f_email text, f_publickey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$  
	
begin
	return query SELECT
        	ud.userid ,
        	ud.created_at ,
        	ud.username ,
        	ud.email ,
        	ud.publickey ,
        	ud.pfp_url 
	FROM
		public.user_data ud
	WHERE
		(select can_add_user_to_org(given_orgid, ud.userid)) = true;
end;
$$;


ALTER FUNCTION public.get_org_addable_member_list(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_all_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_all_notice(given_orgid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	where 
	nt.hierarchy_level = 'org'::public.hierarchy_level_name
	and 
	nt.hierarchy_level_id = given_orgid
	order by nt.created_at desc;
end;
$$;


ALTER FUNCTION public.get_org_all_notice(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_all_threads(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_all_threads(given_orgid uuid) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text)
    LANGUAGE plpgsql
    AS $$
declare
	_team record:=null;
	_thread record:=null;
begin	
	create table res (f_threadid uuid, f_created_at timestamptz, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text);
	
	for _team in
		select t.teamid from public.teams t where t.parent_orgid = given_orgid
	loop 
		for _thread in
			select * from public.threads t2 join public.thread_at_team tat on t2.threadid = tat.threadid where tat.teamid = _team.teamid and t2.is_active = false order by tat.created_at desc
		loop
			insert into res 
			values 
			(
				_thread.threadid,
				_thread.created_at,
				_thread.threadname,
				_thread.parent_teamid,
				_thread.description,
				_thread.is_active,
				_thread.closing_comment
			);
			
		end loop;
		
		
	end loop;
	
	return query select * from res;
	drop table if exists res;
end;
$$;


ALTER FUNCTION public.get_org_all_threads(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_details(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_details(given_orgid uuid) RETURNS record
    LANGUAGE plpgsql
    AS $$  
declare
	_r record:=null;
	_team_c integer:=0;
	_thread_c integer:=0;
	_file_c integer:= 0;
	_member_c integer:=0;
begin
	create table org_data(f_orgid uuid, f_created_at timestamp with time zone, f_org_name text, f_description text, f_team_count integer, f_thread_count integer, f_member_count integer, f_file_count integer);
	SELECT
            	*
	into
		_r
	FROM
		public.organizations o
	WHERE
		o.orgid  = given_orgid;
	select count (t.teamid) into _team_c from public.teams t where t.parent_orgid  = given_orgid;
	select into _thread_c public.get_org_threads_count(given_orgid);
	select count (uao.userid) into _member_c from public.user_at_orgs uao where uao.orgid  = given_orgid;
	select count (fao.fileid) into _file_c from public.file_at_org fao where fao.orgid = given_orgid;

	insert into org_data 
	values
	(
		_r.orgid,
		_r.created_at,
		_r.org_name,
		_r.description,
		_team_c,
		_thread_c,
		_member_c,
		_file_c
	);
	select * into _r from org_data od where od.f_orgid = given_orgid;
	drop table if exists org_data;
	return _r;
end;
$$;


ALTER FUNCTION public.get_org_details(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_file_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_file_list(given_orgid uuid) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	ft.fileid,
            	 ft.created_at,
            	 fd.file_ownerid,
            	 fd.current_custodianid,
            	 fd.current_state ,
            	 fd.custody_type ,
            	 fd.file_url,
            	 fd.filename,
            	 fd.file_extension,
            	 fd.file_mimetype
            	
	FROM
		public.file_at_org ft join public.file_data fd on ft.fileid = fd.fileid 
	WHERE
		ft.orgid = given_orgid
	order by ft.created_at desc;

end;
$$;


ALTER FUNCTION public.get_org_file_list(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_member_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_member_list(given_orgid uuid) RETURNS TABLE(f_joined_at timestamp with time zone, f_userid uuid, f_teamid uuid, f_user_role public.member_level_name, f_user_post text, f_created_at timestamp with time zone, f_username text, f_email text, f_publickey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	uat.joined_at,
        	uat.userid,
        	uat.orgid,
        	uat.user_role,
		uat.user_post,
		ud.created_at,
		ud.username,
		ud.email,
		ud.publickey,
		ud.pfp_url
	FROM
		public.user_data ud join public.user_at_orgs uat on ud.userid = uat.userid 
	WHERE
		uat.orgid  = given_orgid;
end;
$$;


ALTER FUNCTION public.get_org_member_list(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_mods_details(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_mods_details(given_orgid uuid) RETURNS TABLE(f_userid uuid, f_username text, f_pfp_url text, f_user_post text, f_role public.member_level_name)
    LANGUAGE plpgsql
    AS $$
declare
	
begin
	return query SELECT
        	ud.userid ,
        	ud.username ,
        	ud.pfp_url,
        	uat.user_post,
        	uat.user_role 
	FROM
		public.user_data ud  join public.user_at_orgs uat on ud.userid = uat.userid 
	WHERE
		uat.orgid = given_orgid
		and
		( uat.user_role = 'admin' )
	order by 
		uat.joined_at desc;
	
end;
$$;


ALTER FUNCTION public.get_org_mods_details(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_seen_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_seen_notice(given_orgid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	where 
	nt.hierarchy_level = 'org'::public.hierarchy_level_name
	and 
	nt.hierarchy_level_id = given_orgid
	and 
	public.is_notice_seen(nt.noticeid) = true;
	
end;
$$;


ALTER FUNCTION public.get_org_seen_notice(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_team_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_team_list(given_orgid uuid) RETURNS TABLE(f_teamid uuid, f_created_at timestamp with time zone, f_parent_orgid uuid, f_team_name text, f_description text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	t.teamid ,
        	t.created_at ,
        	t.parent_orgid ,
        	t.team_name ,
        	t.t_description 
	FROM
		public.teams t  
	WHERE
		t.parent_orgid = given_orgid
	order by t.created_at desc;
end;
$$;


ALTER FUNCTION public.get_org_team_list(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_threads(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_threads(given_orgid uuid) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text)
    LANGUAGE plpgsql
    AS $$
declare
	_team record:=null;
	_thread record:=null;
begin	
	create table res (f_threadid uuid, f_created_at timestamptz, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text);
	
	for _team in
		select t.teamid from public.teams t where t.parent_orgid = given_orgid
	loop 
		for _thread in
			select * from public.threads t2 join public.thread_at_team tat on t2.threadid = tat.threadid where tat.teamid = _team.teamid order by tat.created_at desc
		loop
			insert into res 
			values 
			(
				_thread.threadid,
				_thread.created_at,
				_thread.threadname,
				_thread.parent_teamid,
				_thread.description,
				_thread.is_active,
				_thread.closing_comment
			);
			
		end loop;
		
		
	end loop;
	
	return query select * from res;
	drop table if exists res;
end;
$$;


ALTER FUNCTION public.get_org_threads(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_threads_count(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_threads_count(given_orgid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
	_result integer:=0;
	_temp integer:=0;
	_team record:=null;
	_thread record:=null;
begin	
	
	for _team in
		select t.teamid from public.teams t where t.parent_orgid = given_orgid
	loop 
		select count(tat.threadid) into _temp from public.thread_at_team tat where tat.teamid = _team.teamid;
		_result := _result + _temp;
		
	end loop;
	
	
	return _result;
end;
$$;


ALTER FUNCTION public.get_org_threads_count(given_orgid uuid) OWNER TO postgres;

--
-- Name: get_org_unseen_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_org_unseen_notice(given_orgid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	where 
	nt.hierarchy_level = 'org'::public.hierarchy_level_name
	and 
	nt.hierarchy_level_id = given_orgid
	and 
	public.is_notice_seen(nt.noticeid) = false;
	
end;
$$;


ALTER FUNCTION public.get_org_unseen_notice(given_orgid uuid) OWNER TO postgres;

--
-- Name: file_signatures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_signatures (
    file_signatureid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    fileid uuid,
    signing_userid uuid,
    signature text,
    note text,
    signature_serial integer,
    signing_key text
);


ALTER TABLE public.file_signatures OWNER TO postgres;

--
-- Name: get_personal_file_signatures_fileid(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_personal_file_signatures_fileid(given_fileid uuid, given_userid uuid) RETURNS public.file_signatures
    LANGUAGE plpgsql
    AS $$

declare 
	t_file_signature record:=null;
begin 
	select
	*
	into t_file_signature
	from 
	public.file_signatures fs2 
	where
	fs2.signing_userid  = given_userid
	and
	fs2.fileid = given_fileid;
	return t_file_signature;
end;
$$;


ALTER FUNCTION public.get_personal_file_signatures_fileid(given_fileid uuid, given_userid uuid) OWNER TO postgres;

--
-- Name: get_post(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_post(given_postid uuid) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare 
	_t record:=null;
	_post_data jsonb:=null;
	_child_post_2 jsonb:=null;
	_child_post record:=null;
	_children jsonb[]:=null;
begin 
	select 
		fp.*, ud.username , ud.email ,ud.created_at as joined_at, ud.pfp_url , ud.publickey 
	into _t from public.forum_posts fp join public.user_data ud on fp.creator_id = ud.userid where fp.postid = given_postid;
	
	_post_data := to_jsonb(_t);
	if _t.is_node <> true then
	for _child_post in 
		select * from public.forum_posts fp where fp.parent_id = _t.postid order by fp.created_at desc
		loop 
--			raise notice '(%)', ( );
			select into _child_post_2  public.get_post(_child_post.postid);
			
			_children := _children || to_jsonb(_child_post_2);
		end loop;
	end if;

	_post_data := _post_data || jsonb_build_object( 'children',  to_jsonb( _children)) ;
	
	
	return _post_data;
end;

$$;


ALTER FUNCTION public.get_post(given_postid uuid) OWNER TO postgres;

--
-- Name: file_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_data (
    fileid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    file_ownerid uuid,
    current_custodianid uuid,
    current_state public.file_state_name,
    custody_type public.custody_type_name,
    file_url text,
    filename text,
    file_extension text,
    file_mimetype bigint,
    filename_search_col tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, COALESCE(filename, ''::text))) STORED
);


ALTER TABLE public.file_data OWNER TO postgres;

--
-- Name: get_single_filedata_fileid(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_single_filedata_fileid(given_fileid uuid, given_userid uuid) RETURNS public.file_data
    LANGUAGE plpgsql
    AS $$
declare 
	t_file_data record:=null;
begin 
	select
	*
	into t_file_data
	from 
	public.file_data u
	where
	u.fileid  = given_fileid
	and 
	u.current_custodianid  = given_userid;
	return t_file_data;
end;
$$;


ALTER FUNCTION public.get_single_filedata_fileid(given_fileid uuid, given_userid uuid) OWNER TO postgres;

--
-- Name: get_single_filemetadata_fileid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_single_filemetadata_fileid(given_fileid uuid) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare 
	t_file_data record:=null;
begin 
	select
	*
	into t_file_data
	from 
	public.file_data u join public.user_data ud
	on u.current_custodianid = ud.userid 
	where
	u.fileid  = given_fileid
	;
	return t_file_data;
end;
$$;


ALTER FUNCTION public.get_single_filemetadata_fileid(given_fileid uuid) OWNER TO postgres;

--
-- Name: get_team_active_thread_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_active_thread_list(given_teamid uuid) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	th.threadid ,
        	th.created_at ,
        	th.threadname ,
        	th.parent_teamid ,
        	th.description ,
        	th.is_active ,
        	th.closing_comment 
	FROM
		public.threads th  
	WHERE
		th.threadid  in (select tat.threadid from public.thread_at_team tat where tat.teamid = given_teamid)
	and th.is_active  = true;
end;
$$;


ALTER FUNCTION public.get_team_active_thread_list(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_addable_member_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_addable_member_list(given_teamid uuid) RETURNS TABLE(f_joined_at timestamp with time zone, f_userid uuid, f_orgid uuid, f_user_role public.member_level_name, f_user_post text, f_created_at timestamp with time zone, f_username text, f_email text, f_publickey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$  
declare 
	_team_org_id uuid:=null;
	
begin
	select t.parent_orgid into _team_org_id from public.teams t where t.teamid  = given_teamid;
	return query SELECT
        	uao.joined_at,
        	uao.userid,
        	uao.orgid,
        	uao.user_role,
		uao.user_post,
		ud.created_at,
		ud.username,
		ud.email,
		ud.publickey,
		ud.pfp_url
	FROM
		public.user_data ud join public.user_at_orgs uao on ud.userid = uao.userid 
	WHERE
		uao.orgid = _team_org_id 
		and 
		(select can_add_user_to_team(given_teamid, uao.userid)) = true;
end;
$$;


ALTER FUNCTION public.get_team_addable_member_list(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_all_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_all_notice(given_teamid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	where 
	nt.hierarchy_level = 'team'::public.hierarchy_level_name
	and 
	nt.hierarchy_level_id = given_teamid
	order by nt.created_at desc
	;
	
end;
$$;


ALTER FUNCTION public.get_team_all_notice(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_archived_thread_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_archived_thread_list(given_teamid uuid) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	th.threadid ,
        	th.created_at ,
        	th.threadname ,
        	th.parent_teamid ,
        	th.description ,
        	th.is_active ,
        	th.closing_comment 
	FROM
		public.threads th  
	WHERE
		th.threadid  in (select tat.threadid from public.thread_at_team tat where tat.teamid = given_teamid)
	and th.is_active  = false;
end;
$$;


ALTER FUNCTION public.get_team_archived_thread_list(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_details(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_details(given_teamid uuid) RETURNS record
    LANGUAGE plpgsql
    AS $$  
declare
	_r record:=null;
	_file_c integer:= 0;
	_member_c integer:=0;
	_thread_c integer:=0;
begin
	create table team_data(f_teamid uuid, f_created_at timestamp with time zone, f_team_name text, f_description text, f_parent_orgid uuid, f_thread_count integer, f_member_count integer, f_file_count integer);
	SELECT
            	*
	into
		_r
	FROM
		public.teams t
	WHERE
		t.teamid  = given_teamid;
	
	select count (uao.userid) into _member_c from public.user_at_teams uao where uao.teamid  = given_teamid;
	select count (fao.fileid) into _file_c from public.file_at_team fao where fao.teamid = given_teamid;
	select count (tt.threadid) into _thread_c from public.thread_at_team tt where tt.teamid = given_teamid;
	insert into team_data 
	values
	(
		_r.teamid,
		_r.created_at,
		_r.team_name,
		_r.t_description,
		_r.parent_orgid,
		_thread_c,
		_member_c,
		_file_c
	);
	select * into _r from team_data od where od.f_teamid = given_teamid;

	drop table if exists team_data;
	return _r;
end;
$$;


ALTER FUNCTION public.get_team_details(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_file_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_file_list(given_teamid uuid) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	ft.fileid,
            	 ft.created_at,
            	 fd.file_ownerid,
            	 fd.current_custodianid,
            	 fd.current_state ,
            	 fd.custody_type ,
            	 fd.file_url,
            	 fd.filename,
            	 fd.file_extension,
            	 fd.file_mimetype
            	
	FROM
		public.file_at_team ft join public.file_data fd on ft.fileid = fd.fileid 
	WHERE
		ft.teamid = given_teamid;

end;
$$;


ALTER FUNCTION public.get_team_file_list(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_member_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_member_list(given_teamid uuid) RETURNS TABLE(f_joined_at timestamp with time zone, f_userid uuid, f_teamid uuid, f_user_role public.member_level_name, f_user_post text, f_created_at timestamp with time zone, f_username text, f_email text, f_publickey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	uat.joined_at,
        	uat.userid,
        	uat.teamid,
        	uat.user_role,
		uat.user_post,
		ud.created_at,
		ud.username,
		ud.email,
		ud.publickey,
		ud.pfp_url
	FROM
		public.user_data ud join public.user_at_teams uat on ud.userid = uat.userid 
	WHERE
		uat.teamid = given_teamid
	order by uat.joined_at desc;
end;
$$;


ALTER FUNCTION public.get_team_member_list(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_mods_details(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_mods_details(given_teamid uuid) RETURNS TABLE(f_userid uuid, f_username text, f_pfp_url text, f_user_post text, f_role public.member_level_name)
    LANGUAGE plpgsql
    AS $$
declare
	
begin
	return query SELECT
        	ud.userid ,
        	ud.username ,
        	ud.pfp_url,
        	uat.user_post,
        	uat.user_role 
	FROM
		public.user_data ud  join public.user_at_teams uat on ud.userid = uat.userid 
	WHERE
		uat.teamid = given_teamid
		and
		( uat.user_role = 'admin' )
	order by
		uat.joined_at desc;
	
end;
$$;


ALTER FUNCTION public.get_team_mods_details(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_seen_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_seen_notice(given_teamid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	where 
	nt.hierarchy_level = 'team'::public.hierarchy_level_name
	and 
	nt.hierarchy_level_id = given_teamid
	and 
	public.is_notice_seen(nt.noticeid) = true;
	
end;
$$;


ALTER FUNCTION public.get_team_seen_notice(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_thread_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_thread_list(given_teamid uuid) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	th.threadid ,
        	th.created_at ,
        	th.threadname ,
        	th.parent_teamid ,
        	th.description ,
        	th.is_active ,
        	th.closing_comment 
	FROM
		public.threads th  
	WHERE
		th.threadid  in (select tat.threadid from public.thread_at_team tat where tat.teamid = given_teamid)
	order by th.created_at desc;
end;
$$;


ALTER FUNCTION public.get_team_thread_list(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_team_unseen_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_team_unseen_notice(given_teamid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	where 
	nt.hierarchy_level = 'team'::public.hierarchy_level_name
	and 
	nt.hierarchy_level_id = given_teamid
	and 
	public.is_notice_seen(nt.noticeid) = false;
	
end;
$$;


ALTER FUNCTION public.get_team_unseen_notice(given_teamid uuid) OWNER TO postgres;

--
-- Name: get_thread_addable_member_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_addable_member_list(given_threadid uuid) RETURNS TABLE(f_joined_at timestamp with time zone, f_userid uuid, f_teamid uuid, f_user_role public.member_level_name, f_user_post text, f_created_at timestamp with time zone, f_username text, f_email text, f_pwd_hash text, f_publickey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$  
declare 
	_thread_org_id uuid:=null;
	_thread_team_id uuid:= null;
	
begin
	select tat.teamid into _thread_team_id from public.thread_at_team tat where tat.threadid = given_threadid and tat.is_parent = true limit 1;
	select t.parent_orgid into _thread_org_id from public.teams t where t.teamid = _thread_team_id;

	return query SELECT
        	uat.joined_at,
        	uat.userid,
        	uat.orgid,
        	uat.user_role,
		uat.user_post,
		ud.created_at,
		ud.username,
		ud.email,
		ud.pwd_hash,
		ud.publickey,
		ud.pfp_url
	FROM
		public.user_data ud join public.user_at_orgs uat on ud.userid = uat.userid 
	WHERE
		uat.orgid = _thread_org_id 
		and 
		(select can_add_user_to_thread(given_threadid, uat.userid)) = true;
end;
$$;


ALTER FUNCTION public.get_thread_addable_member_list(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_thread_addable_member_list2(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_addable_member_list2(given_threadid uuid) RETURNS TABLE(f_joined_at timestamp with time zone, f_userid uuid, f_teamid uuid, f_user_role public.member_level_name, f_user_post text, f_created_at timestamp with time zone, f_username text, f_email text, f_pwd_hash text, f_publickey text, f_pfp_url text, f_teamname text)
    LANGUAGE plpgsql
    AS $$  
declare 
	_thread_org_id uuid:=null;
	_thread_team_id uuid:= null;
	
begin
	select tat.teamid into _thread_team_id from public.thread_at_team tat where tat.threadid = given_threadid and tat.is_parent = true limit 1;
	select t.parent_orgid into _thread_org_id from public.teams t where t.teamid = _thread_team_id;
	

	return query SELECT
        	uat.joined_at,
        	uat.userid,
        	uat.orgid,
        	uat.user_role,
		uat.user_post,
		ud.created_at,
		ud.username,
		ud.email,
		ud.pwd_hash,
		ud.publickey,
		ud.pfp_url,
		(select get_user_team_from_org(_thread_org_id, ud.userid))
	FROM
		public.user_data ud join public.user_at_orgs uat on ud.userid = uat.userid 
	WHERE
		uat.orgid = _thread_org_id 
		and 
		(select can_add_user_to_thread(given_threadid, uat.userid)) = true;
end;
$$;


ALTER FUNCTION public.get_thread_addable_member_list2(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_thread_all_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_all_notice(given_threadid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	where 
	nt.hierarchy_level = 'thread'::public.hierarchy_level_name
	and 
	nt.hierarchy_level_id = given_threadid
	order by nt.created_at desc;
	
end;
$$;


ALTER FUNCTION public.get_thread_all_notice(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_thread_details(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_details(given_threadid uuid) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	_result record:=null;
	_details record:=null;
	_record record:=null;
	_teams text:='';
begin
	create table temp_thread(threadid uuid, created_at timestamptz, threadname text, description text, is_active boolean, closing_comment text, list_of_teams text);
	SELECT
        	* into _details
	FROM
		public.threads th
	WHERE
		th.threadid  = given_threadid;
	
	for _record in 
		select t.team_name  from public.thread_at_team tat join public.teams t on tat.teamid = t.teamid where tat.threadid = given_threadid
		loop 
			_teams = _teams || ',' || _record.team_name;
		end loop;
	insert into temp_thread
	values 
	( 
		_details.threadid,
		_details.created_at,
		_details.threadname,
		_details.description,
		_details.is_active,
		_details.closing_comment,
		_teams
	);
	select * into _result from temp_thread tt where tt.threadid = given_threadid;
	drop table if exists temp_thread;
	return _result;
end;
$$;


ALTER FUNCTION public.get_thread_details(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_thread_file_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_file_list(given_threadid uuid) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	ft.fileid,
            	 ft.created_at,
            	 fd.file_ownerid,
            	 fd.current_custodianid,
            	 fd.current_state ,
            	 fd.custody_type ,
            	 fd.file_url,
            	 fd.filename,
            	 fd.file_extension,
            	 fd.file_mimetype
            	
	FROM
		public.file_at_thread ft join public.file_data fd on ft.fileid = fd.fileid 
	WHERE
		ft.threadid = given_threadid
	order by ft.created_at desc;

end;
$$;


ALTER FUNCTION public.get_thread_file_list(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_thread_forwardable_members(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_forwardable_members(given_threadid uuid, given_userid uuid) RETURNS TABLE(f_user_id uuid, f_username text, f_email text, f_publickey text, f_pfp_url text, f_created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
begin	
	return query 
		select 
		
			ud.userid ,
			ud.username ,
			ud.email ,
			ud.publickey ,
			ud.pfp_url,
			ud.created_at 
			
		from public.user_data ud 
		join public.user_at_threads uat 
		on ud.userid = uat.userid 
		where 
			ud.userid <> given_userid
			and 
			uat.threadid = given_threadid
			and 
			uat.user_role <> 'passive_member'::public.member_level_name;
			
end;
$$;


ALTER FUNCTION public.get_thread_forwardable_members(given_threadid uuid, given_userid uuid) OWNER TO postgres;

--
-- Name: get_thread_member_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_member_list(given_threadid uuid) RETURNS TABLE(f_joined_at timestamp with time zone, f_userid uuid, f_threadid uuid, f_user_role public.member_level_name, f_signing_serial integer, f_created_at timestamp with time zone, f_username text, f_email text, f_publickey text, f_pfp_url text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
        	uat.joined_at,
        	uat.userid,
        	uat.threadid ,
        	uat.user_role,
		uat.signing_serial,
		ud.created_at,
		ud.username,
		ud.email,
		ud.publickey,
		ud.pfp_url
	FROM
		public.user_data ud join public.user_at_threads uat on ud.userid = uat.userid 
	WHERE
		uat.threadid = given_threadid
	order by 
		uat.signing_serial asc;
end;
$$;


ALTER FUNCTION public.get_thread_member_list(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_thread_mods_details(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_mods_details(given_threadid uuid) RETURNS TABLE(f_userid uuid, f_username text, f_pfp_url text, f_current_custodian boolean, f_role public.member_level_name)
    LANGUAGE plpgsql
    AS $$
declare
	
begin
	return query SELECT
        	ud.userid ,
        	ud.username ,
        	ud.pfp_url,
        	uat.current_custodian,
        	uat.user_role 
	FROM
		public.user_data ud  join public.user_at_threads uat on ud.userid = uat.userid 
	WHERE
		uat.threadid  = given_threadid
		and
		( uat.user_role = 'admin' or uat.current_custodian = true )
	order by 
		uat.joined_at desc;
	
end;
$$;


ALTER FUNCTION public.get_thread_mods_details(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_thread_seen_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_seen_notice(given_threadid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	where 
	nt.hierarchy_level = 'thread'::public.hierarchy_level_name
	and 
	nt.hierarchy_level_id = given_threadid
	and 
	public.is_notice_seen(nt.noticeid) = true;
	
end;
$$;


ALTER FUNCTION public.get_thread_seen_notice(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_thread_unseen_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_thread_unseen_notice(given_threadid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	where 
	nt.hierarchy_level = 'thread'::public.hierarchy_level_name
	and 
	nt.hierarchy_level_id = given_threadid
	and 
	public.is_notice_seen(nt.noticeid) = false;
	
end;
$$;


ALTER FUNCTION public.get_thread_unseen_notice(given_threadid uuid) OWNER TO postgres;

--
-- Name: get_threadfile_notes_list(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_threadfile_notes_list(given_fileid uuid) RETURNS TABLE(f_noteid uuid, f_created_at timestamp with time zone, f_fileid uuid, f_userid uuid, f_content text, f_signature text, f_signing_key text, userid uuid, created_at timestamp with time zone, f_username text, email text, pwd_hash text, publickey text, pfp_url text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	*	
	FROM
		public.file_notes_signatures ft join public.user_data ud on ft.userid = ud.userid 
	WHERE
		ft.fileid  = given_fileid
	order by ft.created_at asc;
		

end;
$$;


ALTER FUNCTION public.get_threadfile_notes_list(given_fileid uuid) OWNER TO postgres;

--
-- Name: get_threadfile_notes_list2(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_threadfile_notes_list2(given_fileid uuid) RETURNS TABLE(f_noteid uuid, f_created_at timestamp with time zone, f_fileid uuid, f_userid uuid, f_content text, f_signature text, f_signing_key text, userid uuid, created_at timestamp with time zone, f_username text, email text, pwd_hash text, publickey text, pfp_url text, f_username_search_col tsvector)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	*	
	FROM
		public.file_notes_signatures ft join public.user_data ud on ft.userid = ud.userid 
	WHERE
		ft.fileid  = given_fileid
	order by ft.created_at asc;
		

end;
$$;


ALTER FUNCTION public.get_threadfile_notes_list2(given_fileid uuid) OWNER TO postgres;

--
-- Name: get_user_active_threads(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_active_threads(given_userid uuid) RETURNS TABLE(f_joined_at timestamp with time zone, f_user_role public.member_level_name, f_signing_serial integer, f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_description text, f_parent_teamid uuid, f_is_active boolean, f_closing_comment text)
    LANGUAGE plpgsql
    AS $$  
declare
	_r record:=null;
begin
	return query SELECT
            	uat.joined_at ,
            	uat.user_role ,
            	uat.signing_serial ,
            	t2.threadid ,
            	t2.created_at ,
            	t2.threadname ,
            	t2.description ,
            	t2.parent_teamid ,
            	t2.is_active ,
            	t2.closing_comment 
	FROM
		public.user_at_threads uat join public.threads t2 on uat.threadid = t2.threadid 
	WHERE
		uat.userid = given_userid
		and
		t2.is_active = true;
end;
$$;


ALTER FUNCTION public.get_user_active_threads(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_all_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_all_notice(given_userid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
declare
	_noticeid uuid:=null;
	_user record:=null;
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	join
	public.user_notices_list nf
	on nt.noticeid = nf.noticeid
	where 
	nf.userid = given_userid
	order by nt.created_at desc;
end;
$$;


ALTER FUNCTION public.get_user_all_notice(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_all_publickey_userid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_all_publickey_userid(given_userid uuid) RETURNS TABLE(f_userid uuid, f_created_at timestamp with time zone, f_publickey text)
    LANGUAGE plpgsql
    AS $$

begin 
	return query
	select
	*
	from 
	public.user_publickey_history uph 
	where
	uph.userid = given_userid
	order by 
	uph.created_at desc;
end;
$$;


ALTER FUNCTION public.get_user_all_publickey_userid(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_all_threads(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_all_threads(given_userid uuid) RETURNS TABLE(f_joined_at timestamp with time zone, f_user_role public.member_level_name, f_signing_serial integer, f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_description text, f_parent_teamid uuid, f_is_active boolean, f_closing_comment text)
    LANGUAGE plpgsql
    AS $$  
declare
	_r record:=null;
begin
	return query SELECT
            	uat.joined_at ,
            	uat.user_role ,
            	uat.signing_serial ,
            	t2.threadid ,
            	t2.created_at ,
            	t2.threadname ,
            	t2.description ,
            	t2.parent_teamid ,
            	t2.is_active ,
            	t2.closing_comment 
	FROM
		public.user_at_threads uat join public.threads t2 on uat.threadid = t2.threadid 
	WHERE
		uat.userid = given_userid
	order by uat.joined_at desc;
end;
$$;


ALTER FUNCTION public.get_user_all_threads(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_archived_threads(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_archived_threads(given_userid uuid) RETURNS TABLE(f_joined_at timestamp with time zone, f_user_role public.member_level_name, f_signing_serial integer, f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_description text, f_parent_teamid uuid, f_is_active boolean, f_closing_comment text)
    LANGUAGE plpgsql
    AS $$  
declare
	_r record:=null;
begin
	return query SELECT
            	uat.joined_at ,
            	uat.user_role ,
            	uat.signing_serial ,
            	t2.threadid ,
            	t2.created_at ,
            	t2.threadname ,
            	t2.description ,
            	t2.parent_teamid ,
            	t2.is_active ,
            	t2.closing_comment 
	FROM
		public.user_at_threads uat join public.threads t2 on uat.threadid = t2.threadid 
	WHERE
		uat.userid = given_userid
		and
		t2.is_active = false 
	order by uat.joined_at desc;
end;
$$;


ALTER FUNCTION public.get_user_archived_threads(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_detail_pubkey(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_detail_pubkey(given_pubkey text) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare 
	_t record:=null;
begin
	select 
		ud.userid , ud.username , ud.email , ud.pfp_url 
	into
		_t
	from
		public.user_data ud join public.user_publickey_history uph on ud.userid = uph.userid 
	where
		uph.publickey = given_pubkey;
	return _t;
end;
$$;


ALTER FUNCTION public.get_user_detail_pubkey(given_pubkey text) OWNER TO postgres;

--
-- Name: get_user_details_email(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_details_email(given_email text) RETURNS public.user_data
    LANGUAGE plpgsql
    AS $$
declare 
	t_user_data record:=null;
begin 
	select
	*
	into t_user_data
	from 
	public.user_data u
	where
	u.email  = given_email;
	return t_user_data;
end;
$$;


ALTER FUNCTION public.get_user_details_email(given_email text) OWNER TO postgres;

--
-- Name: get_user_details_email2(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_details_email2(given_email text) RETURNS public.user_data
    LANGUAGE plpgsql
    AS $_$
declare 
	t_user_data record:=null;
begin 
	execute 'select * from public.user_data u where u.email = $1' into t_user_data using given_email;
--	execute s(given_email);
	return t_user_data;
end;
$_$;


ALTER FUNCTION public.get_user_details_email2(given_email text) OWNER TO postgres;

--
-- Name: get_user_details_userid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_details_userid(given_userid uuid) RETURNS public.user_data
    LANGUAGE plpgsql
    AS $$
declare 
	t_user_data record:=null;
begin 
	select
	*
	into t_user_data
	from 
	public.user_data u
	where
	u.userid = given_userid;
	return t_user_data;
end;
$$;


ALTER FUNCTION public.get_user_details_userid(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_live_notifications(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_live_notifications(given_userid uuid) RETURNS TABLE(f_notificationid uuid, f_created_at timestamp with time zone, f_target_userid uuid, f_src_userid uuid, f_content text, f_threadid uuid, f_teamid uuid, f_orgid uuid, f_is_seen boolean, f_fileid uuid, f_is_sent boolean, f_noticeid uuid)
    LANGUAGE plpgsql
    AS $$


begin
	return query select 
		*
	from 
		public.live_notifications ln2
	where 
		ln2.target_userid = given_userid
		and
		ln2.is_seen = false
	order by ln2.created_at desc;
end;
$$;


ALTER FUNCTION public.get_user_live_notifications(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_org_detail_pubkey(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_org_detail_pubkey(given_pubkey text, given_orgid uuid) RETURNS TABLE(f_userid uuid, f_username text, f_email text, f_pfp_url text, f_teamid uuid, f_team_name text, f_user_role public.member_level_name)
    LANGUAGE plpgsql
    AS $$
declare 
	_0 record:=null;
begin
	create table _t(
			userid uuid, username text, email text, pfp_url text, 
			teamid uuid, team_name text, user_role member_level_name
			);

	select
		*
	into 
		_0
	from	
		public.user_data ud join public.user_publickey_history uph on ud.userid = uph.userid 
	where
		uph.publickey = given_pubkey;
	insert into
		_t
	values
		(_0.userid, _0.username, _0.email, _0.pfp_url, null, null, null);
	
	insert into
		_t
	select 
		_0.userid , _0.username, _0.email, _0.pfp_url, uat.teamid, t.team_name , uat.user_role
	from
		public.user_at_teams uat join public.teams t on uat.teamid = t.teamid 
	where
		uat.userid = _0.userid and t.parent_orgid = given_orgid;
	return query select * from _t;
	drop table if exists _t;		
end;
$$;


ALTER FUNCTION public.get_user_org_detail_pubkey(given_pubkey text, given_orgid uuid) OWNER TO postgres;

--
-- Name: get_user_orgs_userid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_orgs_userid(given_userid uuid) RETURNS TABLE(f_orgid uuid, f_created_at timestamp with time zone, f_org_name text, f_description text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	t.orgid ,
            	t.created_at ,
            	t.org_name ,
            	t.description 
	FROM
		public.user_at_orgs uat join public.organizations t on uat.orgid = t.orgid 
	WHERE
		uat.userid = given_userid;
end;
$$;


ALTER FUNCTION public.get_user_orgs_userid(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_personal_file_single_userid(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_personal_file_single_userid(given_userid uuid, given_fileid uuid) RETURNS public.file_data
    LANGUAGE plpgsql
    AS $$  
declare 
	t_file_data record:=null;
begin
	SELECT
            	* into t_file_data
	FROM
		public.file_data
	WHERE
		file_data.file_ownerid = given_userid
        AND
        	file_data.fileid  = given_fileid;
        return t_file_data;
end;
$$;


ALTER FUNCTION public.get_user_personal_file_single_userid(given_userid uuid, given_fileid uuid) OWNER TO postgres;

--
-- Name: get_user_personal_files_by_type_userid_mohaimin(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_personal_files_by_type_userid_mohaimin(given_userid uuid, given_file_extension text) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint)
    LANGUAGE plpgsql
    AS $$  
begin
	if given_file_extension <> '' then 
	return query SELECT
            	*
	FROM
		public.file_data
	WHERE
		file_data.file_ownerid = given_userid
        AND
        	file_data.current_state = 'personal'
        and
        	file_data.file_extension = given_file_extension;
        else 
        return query SELECT
            	*
	FROM
		public.file_data
	WHERE
		file_data.file_ownerid = given_userid
        AND
        	file_data.current_state = 'personal';
        end if;
end;
$$;


ALTER FUNCTION public.get_user_personal_files_by_type_userid_mohaimin(given_userid uuid, given_file_extension text) OWNER TO postgres;

--
-- Name: get_user_personal_files_by_type_userid_sadif(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_personal_files_by_type_userid_sadif(given_userid uuid, given_file_extension text) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint)
    LANGUAGE plpgsql
    AS $$   
begin 
 return query SELECT 
             * 
 FROM 
  public.file_data 
 WHERE 
  file_data.file_ownerid = given_userid 
        AND 
         file_data.current_state = 'personal' 
        and 
         file_data.file_extension = given_file_extension; 
end; 
$$;


ALTER FUNCTION public.get_user_personal_files_by_type_userid_sadif(given_userid uuid, given_file_extension text) OWNER TO postgres;

--
-- Name: get_user_personal_files_userid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_personal_files_userid(given_userid uuid) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	fd.fileid ,
            	fd.created_at ,
            	fd.file_ownerid ,
            	fd.current_custodianid ,
            	fd.current_state ,
            	fd.custody_type ,
            	fd.file_url ,
            	fd.filename ,
            	fd.file_extension ,
            	fd.file_mimetype 
	FROM
		public.file_data fd
	WHERE
		fd.file_ownerid = given_userid
        AND
        	fd.current_state = 'personal'
        order by fd.created_at desc;
end;
$$;


ALTER FUNCTION public.get_user_personal_files_userid(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_publickey_userid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_publickey_userid(given_userid uuid) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare 
	t_publickey text:=null;
begin 
	select
	u.publickey 
	into t_publickey
	from 
	public.user_data u
	where
	u.userid = given_userid;
	return t_publickey;
end;
$$;


ALTER FUNCTION public.get_user_publickey_userid(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_seen_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_seen_notice(given_userid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
declare
	_noticeid uuid:=null;
	_user record:=null;
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	join
	public.user_notices_list nf
	on nt.noticeid = nf.noticeid
	where 
	nf.userid = given_userid 
	and 
	nf.is_seen = true;
end;
$$;


ALTER FUNCTION public.get_user_seen_notice(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_team_from_org(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_team_from_org(given_orgid uuid, given_userid uuid) RETURNS text
    LANGUAGE plpgsql
    AS $$  
declare 
	_team_name text:=null;
	
begin
	select t2.team_name  into _team_name from public.user_at_teams uat join public.teams t2 on uat.teamid = t2.teamid 
	where uat.userid = given_userid 
	and 
	uat.teamid  in 
	(
		select t.teamid from public.teams t where t.parent_orgid = given_orgid
	)
	order by uat.joined_at asc limit 1;
	return _team_name;
end;
$$;


ALTER FUNCTION public.get_user_team_from_org(given_orgid uuid, given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_teams_userid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_teams_userid(given_userid uuid) RETURNS TABLE(f_teamid uuid, f_created_at timestamp with time zone, f_parent_orgid uuid, f_team_name text, f_t_description text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	t.teamid ,
            	t.created_at ,
            	t.parent_orgid ,
            	t.team_name ,
            	t.t_description 
	FROM
		public.user_at_teams uat join public.teams t on uat.teamid = t.teamid 
	WHERE
		uat.userid = given_userid
	order by uat.joined_at desc;
end;
$$;


ALTER FUNCTION public.get_user_teams_userid(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_unseen_notice(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_unseen_notice(given_userid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid)
    LANGUAGE plpgsql
    AS $$
declare
	_noticeid uuid:=null;
	_user record:=null;
begin 
	return query
	select 
	nt.noticeid ,
	nt.created_at ,
	nt.creator_id ,
	nt.hierarchy_level ,
	nt.subject ,
	nt."content" ,
	nt.hierarchy_level_id ,
	nt.related_file_id 
	from 
	public.notices nt
	join
	public.user_notices_list nf
	on nt.noticeid = nf.noticeid
	where 
	nf.userid = given_userid 
	and 
	nf.is_seen = false;
end;
$$;


ALTER FUNCTION public.get_user_unseen_notice(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_unsent_notifications(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_unsent_notifications(given_userid uuid) RETURNS TABLE(f_notificationid uuid, f_created_at timestamp with time zone, f_target_userid uuid, f_src_userid uuid, f_content text, f_threadid uuid, f_teamid uuid, f_orgid uuid, f_is_seen boolean, f_fileid uuid, f_is_sent boolean, f_noticeid uuid)
    LANGUAGE plpgsql
    AS $$


begin
	return query select 
		*
	from 
		public.live_notifications ln2
	where 
		ln2.target_userid = given_userid
		and
		ln2.is_seen = false
		and 
		ln2.is_sent = false
	order by ln2.created_at desc;
	update public.live_notifications 
	set is_sent = true
	where target_userid = given_userid;
end;
$$;


ALTER FUNCTION public.get_user_unsent_notifications(given_userid uuid) OWNER TO postgres;

--
-- Name: get_user_workfiles_userid(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_workfiles_userid(given_userid uuid) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	file_data.fileid,
    		file_data.created_at,
            	file_data.file_ownerid,
    		file_data.current_custodianid,
    		file_data.current_state,
    		file_data.custody_type,
    		file_data.file_url,
    		file_data.filename,
    		file_data.file_extension
	FROM
		public.file_data
	WHERE
		file_data.file_ownerid = given_userid
        AND
       		file_data.current_state <> 'personal'
       	order by file_data.created_at desc;
end;
$$;


ALTER FUNCTION public.get_user_workfiles_userid(given_userid uuid) OWNER TO postgres;

--
-- Name: is_admin(public.hierarchy_level_name, uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.is_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare 
	_u public.member_level_name:=null;
begin 
	if given_hierarchy_level = 'org'::public.hierarchy_level_name then 
		select uao.user_role into _u from public.user_at_orgs uao where uao.userid = target_userid and uao.orgid  = given_hierarchy_level_id;
	elsif given_hierarchy_level = 'team'::public.hierarchy_level_name then 
		select uao.user_role into _u from public.user_at_teams uao where uao.userid = target_userid and uao.teamid = given_hierarchy_level_id;
	elsif given_hierarchy_level = 'thread'::public.hierarchy_level_name then 
		select uao.user_role into _u from public.user_at_threads uao where uao.userid = target_userid and uao.threadid = given_hierarchy_level_id;
	end if;
	if _u = 'admin'::public.member_level_name then 
		return true;
	else 
		return false;
	end if;
	
end;
$$;


ALTER FUNCTION public.is_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) OWNER TO postgres;

--
-- Name: is_member_of(uuid, uuid, public.hierarchy_level_name); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.is_member_of(given_userid uuid, given_hierarchy_id uuid, given_hierarchy_name public.hierarchy_level_name) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare 
	_c integer:=0;
begin
	
	if given_hierarchy_name = 'org'::public.hierarchy_level_name then 
		select count(uao.orgid) into _c from public.user_at_orgs uao where uao.orgid = given_hierarchy_id and uao.userid = given_userid;
	elsif given_hierarchy_name = 'team'::public.hierarchy_level_name then
		select count(uao.teamid) into _c from public.user_at_teams uao where uao.teamid = given_hierarchy_id and uao.userid = given_userid;
	elsif given_hierarchy_name = 'thread'::public.hierarchy_level_name then 
		select count(uao.threadid) into _c from public.user_at_threads uao where uao.threadid  = given_hierarchy_id and uao.userid = given_userid;
	end if;

	if _c = 1 then 
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.is_member_of(given_userid uuid, given_hierarchy_id uuid, given_hierarchy_name public.hierarchy_level_name) OWNER TO postgres;

--
-- Name: is_notice_seen(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.is_notice_seen(given_noticeid uuid) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare 
	_count integer:=0;
begin 
	select count(unl.is_seen) 
	into _count 
	from public.user_notices_list unl 
	where 
	unl.noticeid = given_noticeid
	and
	unl.is_seen = false;
	if _count = 0 then
		return true;
	else 
		return false;
	end if;
end;
$$;


ALTER FUNCTION public.is_notice_seen(given_noticeid uuid) OWNER TO postgres;

--
-- Name: leave_org(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.leave_org(given_orgid uuid, given_userid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$  
declare 
	_r integer:=0;
begin
	delete from public.user_at_threads uat 
	where 
		uat.userid = given_userid
		and 
		uat.threadid in (
					select th.threadid from public.threads th where th.parent_teamid in 
					(
						select te.teamid from public.teams te where te.parent_orgid = given_orgid
					)
				);
	delete from public.user_at_teams uat2
	where 
		uat2.userid = given_userid 
		and 
		uat2.teamid in (
				select te.teamid from public.teams te where te.parent_orgid = given_orgid
				);
	delete from public.user_at_orgs uao where uao.orgid = given_orgid and uao.userid = given_userid;
	get diagnostics _r = row_count;
	return _r;
end;
$$;


ALTER FUNCTION public.leave_org(given_orgid uuid, given_userid uuid) OWNER TO postgres;

--
-- Name: make_admin(public.hierarchy_level_name, uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.make_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare 
	_u integer:=0;
begin 
	if given_hierarchy_level = 'org'::public.hierarchy_level_name then 
		update public.user_at_orgs 
		set user_role = 'admin'
		where userid = target_userid;
	elsif given_hierarchy_level = 'team'::public.hierarchy_level_name then 
		update public.user_at_teams  
		set user_role  = 'admin'
		where userid  = target_userid;
	elsif given_hierarchy_level = 'thread'::public.hierarchy_level_name then 
		update public.user_at_threads 
		set user_role  = 'admin'
		where userid  = target_userid;
	end if;
	get diagnostics _u = row_count;
	return _u;
	
end;
$$;


ALTER FUNCTION public.make_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) OWNER TO postgres;

--
-- Name: make_thread_archived(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.make_thread_archived(given_threadid uuid, given_closing_comment text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
	_done integer:=0;
begin
	update 
		public.threads   
	set
		is_active = false, closing_comment = given_closing_comment
	where 
		threadid = given_threadid;
	get DIAGNOSTICS _done = ROW_COUNT;
	return _done;
end;
$$;


ALTER FUNCTION public.make_thread_archived(given_threadid uuid, given_closing_comment text) OWNER TO postgres;

--
-- Name: make_thread_archived(uuid, uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.make_thread_archived(given_threadid uuid, given_current_userid uuid, given_closing_comment text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
	_done integer:=0;
	_temp integer:=0;
	_user record:= null;
	_file record:=null;
	_user_name text:='';
	_hierarchy_name text:='';
begin
	
	select ud.username into _user_name from public.user_data ud where ud.userid = given_current_userid;
	select og.threadname into _hierarchy_name from public.threads  og where og.threadid = given_threadid;
	
	update 
		public.threads   
	set
		is_active = false, closing_comment = given_closing_comment
	where 
		threadid = given_threadid;
	
	for _file in 
		select * from public.file_at_thread fat join public.file_data fd on fat.fileid = fd.fileid where fat.threadid = given_threadid
	loop
		update 
		public.file_data 
		set 
		current_state = 'closed'::file_state_name
		where 
		fileid = _file.fileid;
	end loop;
	
	for _user in 
		select * from public.user_at_threads uat where uat.threadid = given_threadid
	loop
		insert into
	    	public.live_notifications (
	    		target_userid ,
   			src_userid ,
			content ,
			threadid 
	    	)
	    	values (
	    		_user.userid,
	    		given_current_userid,
	    		_user_name || ' closed the thread: ' || _hierarchy_name,
	    		given_threadid
	    	);
	    
	    	update 
	    	public.user_at_threads 
	    	set 
	    	current_custodian = false
	    	where 
	    	userid = _user.userid;
		
	    	get DIAGNOSTICS _temp = ROW_COUNT;
		_done = _done + _temp;
	end loop;
	return _done;
end;
$$;


ALTER FUNCTION public.make_thread_archived(given_threadid uuid, given_current_userid uuid, given_closing_comment text) OWNER TO postgres;

--
-- Name: make_threadfile_viewed_signed(uuid, uuid, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.make_threadfile_viewed_signed(given_current_userid uuid, given_fileid uuid, given_signature text, given_signing_key text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare
	_new_file_signatureid uuid:=null;
	_serial integer:=0;
begin
	select ud.signing_serial into _serial from public.user_at_threads ud where ud.userid = given_current_userid;
	insert into
	public.file_signatures (
			fileid,
		    	signing_userid,
			signature,
			signing_key,
			signature_serial
	)
	values (
		given_fileid,
		given_current_userid,
		given_signature,
		given_signing_key,
		_serial
    	) returning file_signatureid into _new_file_signatureid;
    	update public.file_data 
    	set 
    	current_state = 'signed_viewed_by_custodian'
    	where
    	fileid = given_fileid;
	return _new_file_signatureid;
end;
$$;


ALTER FUNCTION public.make_threadfile_viewed_signed(given_current_userid uuid, given_fileid uuid, given_signature text, given_signing_key text) OWNER TO postgres;

--
-- Name: make_user_notice_seen(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.make_user_notice_seen(given_userid uuid, given_noticeid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
	_changed integer:=0;
begin 
	update public.user_notices_list 
	set 
	is_seen = true
	where
	userid = given_userid 
	and 
	noticeid = given_noticeid;
	get diagnostics _changed = row_count;
	return _changed;
end;
$$;


ALTER FUNCTION public.make_user_notice_seen(given_userid uuid, given_noticeid uuid) OWNER TO postgres;

--
-- Name: search_notices(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_notices(term text) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select

		n.noticeid ,
		n.created_at ,
		n.creator_id ,
		n.hierarchy_level ,
		n.subject ,
		n."content" ,
		n.hierarchy_level_id ,
		n.related_file_id ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', notice_search_col, query) as rank
	FROM
		public.notices n , phraseto_tsquery('english', coalesce(term, '')) query
	WHERE
		(query @@ (n.notice_search_col)
		or
		(coalesce(term, '')) <% (n.subject || ' ' || n."content")
		or
		difference( (coalesce(term, '')), (n.subject || ' ' || n."content")) > 3
		or 
		( n.subject || ' ' || n."content") like ('%' || term || '%'))
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_notices(term text) OWNER TO postgres;

--
-- Name: search_org_notices(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_org_notices(term text, given_orgid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select

		n.noticeid ,
		n.created_at ,
		n.creator_id ,
		n.hierarchy_level ,
		n.subject ,
		n."content" ,
		n.hierarchy_level_id ,
		n.related_file_id ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', notice_search_col, query) as rank
	FROM
		public.notices n, phraseto_tsquery('english', coalesce(term, '')) query
	where
		n.hierarchy_level = 'org'::public.hierarchy_level_name
		and 
		n.hierarchy_level_id = given_orgid
		and
		(query @@ (n.notice_search_col)
		or
		(coalesce(term, '')) <% (n.subject || ' ' || n."content")
		or
		difference( (coalesce(term, '')), (n.subject || ' ' || n."content")) > 3
		or 
		( n.subject || ' ' || n."content") like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_org_notices(term text, given_orgid uuid) OWNER TO postgres;

--
-- Name: search_org_teams(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_org_teams(term text, given_orgid uuid) RETURNS TABLE(f_teamid uuid, f_created_at timestamp with time zone, f_parent_orgid uuid, f_team_name text, f_t_description text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		t.teamid ,
		t.created_at  ,
		t.parent_orgid ,
		t.team_name ,
		t.t_description ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', team_search_col , query) as rank
	FROM
		public.teams t, phraseto_tsquery('english', coalesce(term, '')) query
	where
		t.parent_orgid = given_orgid
		and
		(query @@ (t.team_search_col)
		or
		(coalesce(term, '')) <% (t.team_name || ' ' || t.t_description)
		or
		difference( (coalesce(term, '')), (t.team_name || ' ' || t.t_description)) > 3
		or 
		(t.team_name || ' ' || t.t_description) like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_org_teams(term text, given_orgid uuid) OWNER TO postgres;

--
-- Name: search_org_threads(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_org_threads(term text, given_orgid uuid) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		t.threadid ,
		t.created_at ,
		t.threadname ,
		t.parent_teamid ,
		t.description ,
		t.is_active ,
		t.closing_comment ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', thread_search_col , query) as rank
	FROM
		public.threads t , phraseto_tsquery('english', coalesce(term, '')) query
	where
		t.threadid  in (select tat.threadid from public.thread_at_team tat where tat.teamid in ( select t2.teamid from public.teams t2 where t2.parent_orgid = given_orgid )) 
		and
		(query @@ (t.thread_search_col)
		or
		(coalesce(term, '')) <% (t.threadname  || ' ' || t.description || ' ' || t.closing_comment)
		or
		difference( (coalesce(term, '')), (t.threadname  || ' ' || t.description || ' ' || t.closing_comment)) > 3
		or 
		( t.threadname  || ' ' || t.description || ' ' || t.closing_comment) like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_org_threads(term text, given_orgid uuid) OWNER TO postgres;

--
-- Name: search_orgs(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_orgs(term text) RETURNS TABLE(f_orgid uuid, f_created_at timestamp with time zone, f_org_name text, f_description text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		o.orgid ,
		o.created_at ,
		o.org_name ,
		o.description ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', org_search_col  , query) as rank
	FROM
		public.organizations o, phraseto_tsquery('english', coalesce(term, '')) query
	where
		(query @@ (o.org_search_col)
		or
		(coalesce(term, '')) <% (o.org_name  || ' ' || o.description)
		or
		difference( (coalesce(term, '')), (o.org_name  || ' ' || o.description)) > 3
		or 
		(o.org_name  || ' ' || o.description) like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_orgs(term text) OWNER TO postgres;

--
-- Name: search_team_file(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_team_file(term text, given_teamid uuid) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		fd.fileid ,
		fat.created_at  ,
		fd.file_ownerid ,
		fd.current_custodianid ,
		fd.current_state ,
		fd.custody_type ,
		fd.file_url ,
		fd.filename ,
		fd.file_extension ,
		fd.file_mimetype ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', filename_search_col, query) as rank
	FROM
		public.file_data fd join public.file_at_team fat on fd.fileid = fat.fileid , to_tsquery('simple', coalesce(term, '')) query
	WHERE
		(query @@ (fd.filename_search_col)
		or
		(coalesce(term, '')) % (fd.filename)
		or
		difference( (coalesce(term, '')), fd.filename) > 3
		or 
		fd.filename like ('%' || term || '%'))
		and
		fat.teamid  = given_teamid
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_team_file(term text, given_teamid uuid) OWNER TO postgres;

--
-- Name: search_team_notices(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_team_notices(term text, given_teamid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select

		n.noticeid ,
		n.created_at ,
		n.creator_id ,
		n.hierarchy_level ,
		n.subject ,
		n."content" ,
		n.hierarchy_level_id ,
		n.related_file_id ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', notice_search_col, query) as rank
	FROM
		public.notices n, phraseto_tsquery('english', coalesce(term, '')) query
	where
		n.hierarchy_level = 'team'::public.hierarchy_level_name
		and 
		n.hierarchy_level_id = given_teamid
		and
		(query @@ (n.notice_search_col)
		or
		(coalesce(term, '')) <% (n.subject || ' ' || n."content")
		or
		difference( (coalesce(term, '')), (n.subject || ' ' || n."content")) > 3
		or 
		( n.subject || ' ' || n."content") like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_team_notices(term text, given_teamid uuid) OWNER TO postgres;

--
-- Name: search_team_threads(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_team_threads(term text, given_teamid uuid) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		t.threadid ,
		t.created_at ,
		t.threadname ,
		t.parent_teamid ,
		t.description ,
		t.is_active ,
		t.closing_comment ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', thread_search_col , query) as rank
	FROM
		public.threads t , phraseto_tsquery('english', coalesce(term, '')) query
	where
		t.threadid  in (select tat.threadid from public.thread_at_team tat where tat.teamid = given_teamid) 
		and
		(query @@ (t.thread_search_col)
		or
		(coalesce(term, '')) <% (t.threadname  || ' ' || t.description || ' ' || t.closing_comment)
		or
		difference( (coalesce(term, '')), (t.threadname  || ' ' || t.description || ' ' || t.closing_comment)) > 3
		or 
		( t.threadname  || ' ' || t.description || ' ' || t.closing_comment) like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_team_threads(term text, given_teamid uuid) OWNER TO postgres;

--
-- Name: search_teams(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_teams(term text) RETURNS TABLE(f_teamid uuid, f_created_at timestamp with time zone, f_parent_orgid uuid, f_team_name text, f_t_description text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		t.teamid ,
		t.created_at  ,
		t.parent_orgid ,
		t.team_name ,
		t.t_description ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', team_search_col , query) as rank
	FROM
		public.teams t , phraseto_tsquery('english', coalesce(term, '')) query
	where
		(query @@ (t.team_search_col)
		or
		(coalesce(term, '')) <% (t.team_name || ' ' || t.t_description)
		or
		difference( (coalesce(term, '')), (t.team_name || ' ' || t.t_description)) > 3
		or 
		(t.team_name || ' ' || t.t_description) like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_teams(term text) OWNER TO postgres;

--
-- Name: search_thread_file(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_thread_file(term text, given_threadid uuid) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		fd.fileid ,
		fat.created_at  ,
		fd.file_ownerid ,
		fd.current_custodianid ,
		fd.current_state ,
		fd.custody_type ,
		fd.file_url ,
		fd.filename ,
		fd.file_extension ,
		fd.file_mimetype ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', filename_search_col, query) as rank
	FROM
		public.file_data fd join public.file_at_thread fat on fd.fileid = fat.fileid , to_tsquery('simple', coalesce(term, '')) query
	WHERE
		(query @@ (fd.filename_search_col)
		or
		(coalesce(term, '')) % (fd.filename)
		or
		difference( (coalesce(term, '')), fd.filename) > 3
		or 
		fd.filename like ('%' || term || '%'))
		and
		fat.threadid = given_threadid
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_thread_file(term text, given_threadid uuid) OWNER TO postgres;

--
-- Name: search_thread_notices(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_thread_notices(term text, given_threadid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select

		n.noticeid ,
		n.created_at ,
		n.creator_id ,
		n.hierarchy_level ,
		n.subject ,
		n."content" ,
		n.hierarchy_level_id ,
		n.related_file_id ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', notice_search_col, query) as rank
	FROM
		public.notices n, phraseto_tsquery('english', coalesce(term, '')) query
	where
		n.hierarchy_level = 'thread'::public.hierarchy_level_name
		and 
		n.hierarchy_level_id = given_threadid
		and
		(query @@ (n.notice_search_col)
		or
		(coalesce(term, '')) <% (n.subject || ' ' || n."content")
		or
		difference( (coalesce(term, '')), (n.subject || ' ' || n."content")) > 3
		or 
		( n.subject || ' ' || n."content") like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_thread_notices(term text, given_threadid uuid) OWNER TO postgres;

--
-- Name: search_threads(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_threads(term text) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		t.threadid ,
		t.created_at ,
		t.threadname ,
		t.parent_teamid ,
		t.description ,
		t.is_active ,
		t.closing_comment ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', thread_search_col , query) as rank
	FROM
		public.threads t , phraseto_tsquery('english', coalesce(term, '')) query
	where
		
		(query @@ (t.thread_search_col)
		or
		(coalesce(term, '')) <% (t.threadname  || ' ' || t.description || ' ' || t.closing_comment)
		or
		difference( (coalesce(term, '')), (t.threadname  || ' ' || t.description || ' ' || t.closing_comment)) > 3
		or 
		( t.threadname  || ' ' || t.description || ' ' || t.closing_comment) like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_threads(term text) OWNER TO postgres;

--
-- Name: search_user_by_name(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_user_by_name(term text) RETURNS TABLE(f_userid uuid, f_created_at timestamp with time zone, f_username text, f_email text, f_publickey text, f_pfp_url text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	return query SELECT
            	ud.userid  ,
            	ud.created_at ,
            	ud.username ,
            	ud.email ,
            	ud.publickey ,
            	ud.pfp_url ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', username_search_col, query) as rank
	FROM
		public.user_data ud, to_tsquery('simple', coalesce(term, '')) query
	WHERE
		query @@ (username_search_col)
		or
		(coalesce(term, '')) <% (username)
		or
		difference( (coalesce(term, '')), username) > 3
		or 
		ud.username like ('%' || term || '%')
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_user_by_name(term text) OWNER TO postgres;

--
-- Name: search_user_notices(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_user_notices(term text, given_userid uuid) RETURNS TABLE(f_noticeid uuid, f_created_at timestamp with time zone, f_creator_id uuid, f_hierarchy_level public.hierarchy_level_name, f_subject text, f_content text, f_hierarchy_level_id uuid, f_related_file_id uuid, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select

		n.noticeid ,
		n.created_at ,
		n.creator_id ,
		n.hierarchy_level ,
		n.subject ,
		n."content" ,
		n.hierarchy_level_id ,
		n.related_file_id ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', notice_search_col, query) as rank
	FROM
		public.notices n join public.user_notices_list unl on n.noticeid = unl.noticeid , phraseto_tsquery('english', coalesce(term, '')) query
	where
		unl.userid = given_userid
		and
		(query @@ (n.notice_search_col)
		or
		(coalesce(term, '')) <% (n.subject || ' ' || n."content")
		or
		difference( (coalesce(term, '')), (n.subject || ' ' || n."content")) > 3
		or 
		( n.subject || ' ' || n."content") like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_user_notices(term text, given_userid uuid) OWNER TO postgres;

--
-- Name: search_user_orgs(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_user_orgs(term text, given_userid uuid) RETURNS TABLE(f_orgid uuid, f_created_at timestamp with time zone, f_org_name text, f_description text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		o.orgid ,
		o.created_at ,
		o.org_name ,
		o.description ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', org_search_col  , query) as rank
	FROM
		public.organizations o join public.user_at_orgs uao  on o.orgid = uao.orgid , phraseto_tsquery('english', coalesce(term, '')) query
	where
		uao.userid = given_userid
		and
		(query @@ (o.org_search_col)
		or
		(coalesce(term, '')) <% (o.org_name  || ' ' || o.description)
		or
		difference( (coalesce(term, '')), (o.org_name  || ' ' || o.description)) > 3
		or 
		(o.org_name  || ' ' || o.description) like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_user_orgs(term text, given_userid uuid) OWNER TO postgres;

--
-- Name: search_user_personal_file(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_user_personal_file(term text, given_userid uuid) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	return query select
		fd.fileid ,
		fd.created_at ,
		fd.file_ownerid ,
		fd.current_custodianid ,
		fd.current_state ,
		fd.custody_type ,
		fd.file_url ,
		fd.filename ,
		fd.file_extension ,
		fd.file_mimetype ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', filename_search_col, query) as rank
	FROM
		public.file_data fd, to_tsquery('simple', coalesce(term, '')) query
	WHERE
		(query @@ (filename_search_col)
		or
		(coalesce(term, '')) <% (filename)
		or
		difference( (coalesce(term, '')), filename) > 3
		or 
		fd.filename like ('%' || term || '%'))
		and
		fd.file_ownerid = given_userid 
		and 
		fd.current_state = 'personal'
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_user_personal_file(term text, given_userid uuid) OWNER TO postgres;

--
-- Name: search_user_teams(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_user_teams(term text, given_userid uuid) RETURNS TABLE(f_teamid uuid, f_created_at timestamp with time zone, f_parent_orgid uuid, f_team_name text, f_t_description text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		t.teamid ,
		t.created_at  ,
		t.parent_orgid ,
		t.team_name ,
		t.t_description ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', team_search_col , query) as rank
	FROM
		public.teams t join public.user_at_teams uat on t.teamid = uat.teamid  , phraseto_tsquery('english', coalesce(term, '')) query
	where
		uat.userid = given_userid
		and
		(query @@ (t.team_search_col)
		or
		(coalesce(term, '')) <% (t.team_name || ' ' || t.t_description)
		or
		difference( (coalesce(term, '')), (t.team_name || ' ' || t.t_description)) > 3
		or 
		(t.team_name || ' ' || t.t_description) like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_user_teams(term text, given_userid uuid) OWNER TO postgres;

--
-- Name: search_user_threads(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_user_threads(term text, given_userid uuid) RETURNS TABLE(f_threadid uuid, f_created_at timestamp with time zone, f_threadname text, f_parent_teamid uuid, f_description text, f_is_active boolean, f_closing_comment text, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	
	return query select
		t.threadid ,
		t.created_at ,
		t.threadname ,
		t.parent_teamid ,
		t.description ,
		t.is_active ,
		t.closing_comment ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', thread_search_col , query) as rank
	FROM
		public.threads t join public.user_at_threads uat on t.threadid = uat.threadid  , phraseto_tsquery('english', coalesce(term, '')) query
	where
		uat.userid = given_userid
		and
		(query @@ (t.thread_search_col)
		or
		(coalesce(term, '')) <% (t.threadname  || ' ' || t.description || ' ' || t.closing_comment)
		or
		difference( (coalesce(term, '')), (t.threadname  || ' ' || t.description || ' ' || t.closing_comment)) > 3
		or 
		( t.threadname  || ' ' || t.description || ' ' || t.closing_comment) like ('%' || term || '%'))
		 
		
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_user_threads(term text, given_userid uuid) OWNER TO postgres;

--
-- Name: search_user_work_file(text, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_user_work_file(term text, given_userid uuid) RETURNS TABLE(f_fileid uuid, f_created_at timestamp with time zone, f_file_ownerid uuid, f_current_custodianid uuid, f_current_state public.file_state_name, f_custody_type public.custody_type_name, f_file_url text, f_filename text, f_file_extension text, f_file_mimetype bigint, f_rank real)
    LANGUAGE plpgsql
    AS $$  
begin
	return query select
		fd.fileid ,
		fd.created_at ,
		fd.file_ownerid ,
		fd.current_custodianid ,
		fd.current_state ,
		fd.custody_type ,
		fd.file_url ,
		fd.filename ,
		fd.file_extension ,
		fd.file_mimetype ,
            	ts_rank( '{1.0,0.2,0.0,0.0}', filename_search_col, query) as rank
	FROM
		public.file_data fd, to_tsquery('simple', coalesce(term, '')) query
	WHERE
		(query @@ (filename_search_col)
		or
		(coalesce(term, '')) <% (filename)
		or
		difference( (coalesce(term, '')), filename) > 3
		or 
		fd.filename like ('%' || term || '%'))
		and
		fd.file_ownerid = given_userid 
		and 
		fd.current_state <> 'personal'
		
	order by rank desc;
        
end;
$$;


ALTER FUNCTION public.search_user_work_file(term text, given_userid uuid) OWNER TO postgres;

--
-- Name: set_user_all_notification_seen(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_user_all_notification_seen(given_userid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$

declare 
	_done integer:=0;
begin
	update public.live_notifications 
	set 
		is_seen = true
	where 
		target_userid = given_userid;
	get diagnostics _done = ROW_COUNT;
	return _done;
end;
$$;


ALTER FUNCTION public.set_user_all_notification_seen(given_userid uuid) OWNER TO postgres;

--
-- Name: set_user_notification_seen(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_user_notification_seen(given_userid uuid, given_notificationid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$

declare 
	_done integer:=0;
begin
	update public.live_notifications 
	set 
		is_seen = true
	where 
		target_userid = given_userid 
		and
		notificationid = given_notificationid;
	get diagnostics _done = ROW_COUNT;
	return _done;
end;
$$;


ALTER FUNCTION public.set_user_notification_seen(given_userid uuid, given_notificationid uuid) OWNER TO postgres;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
    select string_to_array(name, '/') into _parts;
    select _parts[array_length(_parts,1)] into _filename;
    -- @todo return the last part instead of 2
    return split_part(_filename, '.', 2);
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
    select string_to_array(name, '/') into _parts;
    return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
    select string_to_array(name, '/') into _parts;
    return _parts[1:array_length(_parts,1)-1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
  v_order_by text;
  v_sort_order text;
begin
  case
    when sortcolumn = 'name' then
      v_order_by = 'name';
    when sortcolumn = 'updated_at' then
      v_order_by = 'updated_at';
    when sortcolumn = 'created_at' then
      v_order_by = 'created_at';
    when sortcolumn = 'last_accessed_at' then
      v_order_by = 'last_accessed_at';
    else
      v_order_by = 'name';
  end case;

  case
    when sortorder = 'asc' then
      v_sort_order = 'asc';
    when sortorder = 'desc' then
      v_sort_order = 'desc';
    else
      v_sort_order = 'asc';
  end case;

  v_order_by = v_order_by || ' ' || v_sort_order;

  return query execute
    'with folders as (
       select path_tokens[$1] as folder
       from storage.objects
         where objects.name ilike $2 || $3 || ''%''
           and bucket_id = $4
           and array_length(regexp_split_to_array(objects.name, ''/''), 1) <> $1
       group by folder
       order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(regexp_split_to_array(objects.name, ''/''), 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

--
-- Name: file_at_org; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_at_org (
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    fileid uuid NOT NULL,
    orgid uuid NOT NULL
);


ALTER TABLE public.file_at_org OWNER TO postgres;

--
-- Name: file_at_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_at_team (
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    fileid uuid NOT NULL,
    teamid uuid NOT NULL
);


ALTER TABLE public.file_at_team OWNER TO postgres;

--
-- Name: file_at_thread; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_at_thread (
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    threadid uuid NOT NULL,
    fileid uuid NOT NULL
);


ALTER TABLE public.file_at_thread OWNER TO postgres;

--
-- Name: file_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_history (
    fileid uuid NOT NULL,
    start_at timestamp with time zone DEFAULT now() NOT NULL,
    custodian_id uuid,
    threadid uuid,
    added_note_count bigint DEFAULT '0'::bigint
);


ALTER TABLE public.file_history OWNER TO postgres;

--
-- Name: file_notes_signatures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file_notes_signatures (
    noteid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    fileid uuid,
    userid uuid,
    content text,
    signature text,
    signing_key text
);


ALTER TABLE public.file_notes_signatures OWNER TO postgres;

--
-- Name: forum_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forum_posts (
    postid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    creator_id uuid,
    post_title text,
    post_content text,
    is_node boolean DEFAULT true,
    is_toplevel boolean DEFAULT true,
    parent_id uuid,
    forumid uuid
);


ALTER TABLE public.forum_posts OWNER TO postgres;

--
-- Name: forums; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forums (
    forumid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    forum_thread_name text,
    creator_id uuid,
    forum_thread_subject text,
    hierarchy_level public.hierarchy_level_name,
    hierarchy_level_id uuid
);


ALTER TABLE public.forums OWNER TO postgres;

--
-- Name: live_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.live_notifications (
    notificationid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    target_userid uuid,
    src_userid uuid,
    content text,
    threadid uuid,
    teamid uuid,
    orgid uuid,
    is_seen boolean DEFAULT false,
    fileid uuid,
    is_sent boolean DEFAULT false,
    noticeid uuid
);


ALTER TABLE public.live_notifications OWNER TO postgres;

--
-- Name: notices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notices (
    noticeid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    creator_id uuid,
    hierarchy_level public.hierarchy_level_name,
    subject text,
    content text,
    hierarchy_level_id uuid,
    related_file_id uuid,
    notice_search_col tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(subject, ' '::text, content))) STORED
);


ALTER TABLE public.notices OWNER TO postgres;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    orgid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    org_name text,
    description text,
    org_search_col tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(org_name, ' '::text, description))) STORED
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teams (
    teamid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    parent_orgid uuid,
    team_name text,
    t_description text,
    team_search_col tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(team_name, ' '::text, t_description))) STORED
);


ALTER TABLE public.teams OWNER TO postgres;

--
-- Name: thread_at_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.thread_at_team (
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    threadid uuid DEFAULT gen_random_uuid() NOT NULL,
    teamid uuid DEFAULT gen_random_uuid() NOT NULL,
    is_parent boolean DEFAULT false
);


ALTER TABLE public.thread_at_team OWNER TO postgres;

--
-- Name: threads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.threads (
    threadid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    threadname text,
    parent_teamid uuid,
    description text DEFAULT ''::text,
    is_active boolean DEFAULT true,
    closing_comment text DEFAULT ''::text,
    thread_search_col tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(threadname, ' '::text, description, ' '::text, closing_comment))) STORED
);


ALTER TABLE public.threads OWNER TO postgres;

--
-- Name: user_at_orgs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_at_orgs (
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    userid uuid NOT NULL,
    orgid uuid NOT NULL,
    user_role public.member_level_name,
    user_post text
);


ALTER TABLE public.user_at_orgs OWNER TO postgres;

--
-- Name: user_at_teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_at_teams (
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    userid uuid NOT NULL,
    teamid uuid NOT NULL,
    user_role public.member_level_name,
    user_post text
);


ALTER TABLE public.user_at_teams OWNER TO postgres;

--
-- Name: user_at_threads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_at_threads (
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    userid uuid NOT NULL,
    threadid uuid NOT NULL,
    user_role public.member_level_name,
    signing_serial integer DEFAULT 0,
    current_custodian boolean DEFAULT false
);


ALTER TABLE public.user_at_threads OWNER TO postgres;

--
-- Name: user_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_devices (
    deviceid uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    userid uuid,
    device_key text
);


ALTER TABLE public.user_devices OWNER TO postgres;

--
-- Name: user_notices_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_notices_list (
    userid uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    noticeid uuid NOT NULL,
    is_seen boolean DEFAULT false
);


ALTER TABLE public.user_notices_list OWNER TO postgres;

--
-- Name: user_publickey_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_publickey_history (
    userid uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    publickey text NOT NULL
);


ALTER TABLE public.user_publickey_history OWNER TO postgres;

--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Data for Name: file_at_org; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_at_org (created_at, fileid, orgid) FROM stdin;
\.
COPY public.file_at_org (created_at, fileid, orgid) FROM '$$PATH$$/4477.dat';

--
-- Data for Name: file_at_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_at_team (created_at, fileid, teamid) FROM stdin;
\.
COPY public.file_at_team (created_at, fileid, teamid) FROM '$$PATH$$/4475.dat';

--
-- Data for Name: file_at_thread; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_at_thread (created_at, threadid, fileid) FROM stdin;
\.
COPY public.file_at_thread (created_at, threadid, fileid) FROM '$$PATH$$/4476.dat';

--
-- Data for Name: file_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_data (fileid, created_at, file_ownerid, current_custodianid, current_state, custody_type, file_url, filename, file_extension, file_mimetype) FROM stdin;
\.
COPY public.file_data (fileid, created_at, file_ownerid, current_custodianid, current_state, custody_type, file_url, filename, file_extension, file_mimetype) FROM '$$PATH$$/4469.dat';

--
-- Data for Name: file_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_history (fileid, start_at, custodian_id, threadid, added_note_count) FROM stdin;
\.
COPY public.file_history (fileid, start_at, custodian_id, threadid, added_note_count) FROM '$$PATH$$/4481.dat';

--
-- Data for Name: file_notes_signatures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_notes_signatures (noteid, created_at, fileid, userid, content, signature, signing_key) FROM stdin;
\.
COPY public.file_notes_signatures (noteid, created_at, fileid, userid, content, signature, signing_key) FROM '$$PATH$$/4482.dat';

--
-- Data for Name: file_signatures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file_signatures (file_signatureid, created_at, fileid, signing_userid, signature, note, signature_serial, signing_key) FROM stdin;
\.
COPY public.file_signatures (file_signatureid, created_at, fileid, signing_userid, signature, note, signature_serial, signing_key) FROM '$$PATH$$/4471.dat';

--
-- Data for Name: forum_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forum_posts (postid, created_at, creator_id, post_title, post_content, is_node, is_toplevel, parent_id, forumid) FROM stdin;
\.
COPY public.forum_posts (postid, created_at, creator_id, post_title, post_content, is_node, is_toplevel, parent_id, forumid) FROM '$$PATH$$/4485.dat';

--
-- Data for Name: forums; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forums (forumid, created_at, forum_thread_name, creator_id, forum_thread_subject, hierarchy_level, hierarchy_level_id) FROM stdin;
\.
COPY public.forums (forumid, created_at, forum_thread_name, creator_id, forum_thread_subject, hierarchy_level, hierarchy_level_id) FROM '$$PATH$$/4486.dat';

--
-- Data for Name: live_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.live_notifications (notificationid, created_at, target_userid, src_userid, content, threadid, teamid, orgid, is_seen, fileid, is_sent, noticeid) FROM stdin;
\.
COPY public.live_notifications (notificationid, created_at, target_userid, src_userid, content, threadid, teamid, orgid, is_seen, fileid, is_sent, noticeid) FROM '$$PATH$$/4480.dat';

--
-- Data for Name: notices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notices (noticeid, created_at, creator_id, hierarchy_level, subject, content, hierarchy_level_id, related_file_id) FROM stdin;
\.
COPY public.notices (noticeid, created_at, creator_id, hierarchy_level, subject, content, hierarchy_level_id, related_file_id) FROM '$$PATH$$/4470.dat';

--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (orgid, created_at, org_name, description) FROM stdin;
\.
COPY public.organizations (orgid, created_at, org_name, description) FROM '$$PATH$$/4468.dat';

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (teamid, created_at, parent_orgid, team_name, t_description) FROM stdin;
\.
COPY public.teams (teamid, created_at, parent_orgid, team_name, t_description) FROM '$$PATH$$/4467.dat';

--
-- Data for Name: thread_at_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.thread_at_team (created_at, threadid, teamid, is_parent) FROM stdin;
\.
COPY public.thread_at_team (created_at, threadid, teamid, is_parent) FROM '$$PATH$$/4483.dat';

--
-- Data for Name: threads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.threads (threadid, created_at, threadname, parent_teamid, description, is_active, closing_comment) FROM stdin;
\.
COPY public.threads (threadid, created_at, threadname, parent_teamid, description, is_active, closing_comment) FROM '$$PATH$$/4466.dat';

--
-- Data for Name: user_at_orgs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_at_orgs (joined_at, userid, orgid, user_role, user_post) FROM stdin;
\.
COPY public.user_at_orgs (joined_at, userid, orgid, user_role, user_post) FROM '$$PATH$$/4474.dat';

--
-- Data for Name: user_at_teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_at_teams (joined_at, userid, teamid, user_role, user_post) FROM stdin;
\.
COPY public.user_at_teams (joined_at, userid, teamid, user_role, user_post) FROM '$$PATH$$/4472.dat';

--
-- Data for Name: user_at_threads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_at_threads (joined_at, userid, threadid, user_role, signing_serial, current_custodian) FROM stdin;
\.
COPY public.user_at_threads (joined_at, userid, threadid, user_role, signing_serial, current_custodian) FROM '$$PATH$$/4473.dat';

--
-- Data for Name: user_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_data (userid, created_at, username, email, pwd_hash, publickey, pfp_url) FROM stdin;
\.
COPY public.user_data (userid, created_at, username, email, pwd_hash, publickey, pfp_url) FROM '$$PATH$$/4465.dat';

--
-- Data for Name: user_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_devices (deviceid, created_at, userid, device_key) FROM stdin;
\.
COPY public.user_devices (deviceid, created_at, userid, device_key) FROM '$$PATH$$/4478.dat';

--
-- Data for Name: user_notices_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_notices_list (userid, created_at, noticeid, is_seen) FROM stdin;
\.
COPY public.user_notices_list (userid, created_at, noticeid, is_seen) FROM '$$PATH$$/4484.dat';

--
-- Data for Name: user_publickey_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_publickey_history (userid, created_at, publickey) FROM stdin;
\.
COPY public.user_publickey_history (userid, created_at, publickey) FROM '$$PATH$$/4479.dat';

--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id) FROM stdin;
\.
COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id) FROM '$$PATH$$/4462.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
\.
COPY storage.migrations (id, name, hash, executed_at) FROM '$$PATH$$/4464.dat';

--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id) FROM stdin;
\.
COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id) FROM '$$PATH$$/4463.dat';

--
-- Name: file_at_org file_at_org_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_at_org
    ADD CONSTRAINT file_at_org_pkey PRIMARY KEY (fileid, orgid);


--
-- Name: file_at_team file_at_team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_at_team
    ADD CONSTRAINT file_at_team_pkey PRIMARY KEY (fileid, teamid);


--
-- Name: file_at_thread file_at_thread_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_at_thread
    ADD CONSTRAINT file_at_thread_pkey PRIMARY KEY (threadid, fileid);


--
-- Name: file_data file_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_data
    ADD CONSTRAINT file_data_pkey PRIMARY KEY (fileid);


--
-- Name: file_history file_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_history
    ADD CONSTRAINT file_history_pkey PRIMARY KEY (fileid, start_at);


--
-- Name: file_notes_signatures file_notes_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_notes_signatures
    ADD CONSTRAINT file_notes_signatures_pkey PRIMARY KEY (noteid);


--
-- Name: file_signatures file_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_signatures
    ADD CONSTRAINT file_signatures_pkey PRIMARY KEY (file_signatureid);


--
-- Name: forum_posts forum_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT forum_posts_pkey PRIMARY KEY (postid);


--
-- Name: forums forums_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forums
    ADD CONSTRAINT forums_pkey PRIMARY KEY (forumid);


--
-- Name: live_notifications live_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_notifications
    ADD CONSTRAINT live_notifications_pkey PRIMARY KEY (notificationid);


--
-- Name: notices notices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notices
    ADD CONSTRAINT notices_pkey PRIMARY KEY (noticeid);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (orgid);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (teamid);


--
-- Name: thread_at_team thread_at_team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thread_at_team
    ADD CONSTRAINT thread_at_team_pkey PRIMARY KEY (threadid, teamid);


--
-- Name: threads threads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.threads
    ADD CONSTRAINT threads_pkey PRIMARY KEY (threadid);


--
-- Name: user_at_orgs user_at_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_at_orgs
    ADD CONSTRAINT user_at_orgs_pkey PRIMARY KEY (userid, orgid);


--
-- Name: user_at_teams user_at_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_at_teams
    ADD CONSTRAINT user_at_teams_pkey PRIMARY KEY (userid, teamid);


--
-- Name: user_at_threads user_at_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_at_threads
    ADD CONSTRAINT user_at_threads_pkey PRIMARY KEY (userid, threadid);


--
-- Name: user_devices user_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_pkey PRIMARY KEY (deviceid, created_at);


--
-- Name: user_notices_list user_notices_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notices_list
    ADD CONSTRAINT user_notices_list_pkey PRIMARY KEY (userid, noticeid);


--
-- Name: user_publickey_history user_publickey_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_publickey_history
    ADD CONSTRAINT user_publickey_history_pkey PRIMARY KEY (userid, publickey);


--
-- Name: user_data users_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_data
    ADD CONSTRAINT users_data_pkey PRIMARY KEY (userid);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: filename_search_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX filename_search_idx ON public.file_data USING gin (filename_search_col);


--
-- Name: filename_tgm_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX filename_tgm_idx ON public.file_data USING gist (((filename || ''::text)) public.gist_trgm_ops (siglen='32'));


--
-- Name: notice_search_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notice_search_idx ON public.notices USING gin (notice_search_col);


--
-- Name: notice_tgm_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notice_tgm_idx ON public.notices USING gist ((((subject || ' '::text) || content)) public.gist_trgm_ops (siglen='256'));


--
-- Name: org_search_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX org_search_idx ON public.organizations USING gin (org_search_col);


--
-- Name: org_tgm_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX org_tgm_idx ON public.organizations USING gist ((((org_name || ' '::text) || description)) public.gist_trgm_ops (siglen='256'));


--
-- Name: team_search_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX team_search_idx ON public.teams USING gin (team_search_col);


--
-- Name: team_tgm_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX team_tgm_idx ON public.teams USING gist ((((team_name || ' '::text) || t_description)) public.gist_trgm_ops (siglen='256'));


--
-- Name: thread_search_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX thread_search_idx ON public.threads USING gin (thread_search_col);


--
-- Name: thread_tgm_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX thread_tgm_idx ON public.threads USING gist ((((((threadname || ' '::text) || description) || ' '::text) || closing_comment)) public.gist_trgm_ops (siglen='256'));


--
-- Name: username_search_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX username_search_idx ON public.user_data USING gin (username_search_col);


--
-- Name: username_tgm_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX username_tgm_idx ON public.user_data USING gist (((username || ''::text)) public.gist_trgm_ops (siglen='32'));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: file_at_org file_at_org_fileid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_at_org
    ADD CONSTRAINT file_at_org_fileid_fkey FOREIGN KEY (fileid) REFERENCES public.file_data(fileid);


--
-- Name: file_at_org file_at_org_orgid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_at_org
    ADD CONSTRAINT file_at_org_orgid_fkey FOREIGN KEY (orgid) REFERENCES public.organizations(orgid);


--
-- Name: file_at_team file_at_team_fileid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_at_team
    ADD CONSTRAINT file_at_team_fileid_fkey FOREIGN KEY (fileid) REFERENCES public.file_data(fileid);


--
-- Name: file_at_team file_at_team_teamid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_at_team
    ADD CONSTRAINT file_at_team_teamid_fkey FOREIGN KEY (teamid) REFERENCES public.teams(teamid);


--
-- Name: file_at_thread file_at_thread_fileid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_at_thread
    ADD CONSTRAINT file_at_thread_fileid_fkey FOREIGN KEY (fileid) REFERENCES public.file_data(fileid);


--
-- Name: file_at_thread file_at_thread_threadid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_at_thread
    ADD CONSTRAINT file_at_thread_threadid_fkey FOREIGN KEY (threadid) REFERENCES public.threads(threadid);


--
-- Name: file_data file_data_current_custodianid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_data
    ADD CONSTRAINT file_data_current_custodianid_fkey FOREIGN KEY (current_custodianid) REFERENCES public.user_data(userid);


--
-- Name: file_data file_data_file_ownerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_data
    ADD CONSTRAINT file_data_file_ownerid_fkey FOREIGN KEY (file_ownerid) REFERENCES public.user_data(userid);


--
-- Name: file_history file_history_custodian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_history
    ADD CONSTRAINT file_history_custodian_id_fkey FOREIGN KEY (custodian_id) REFERENCES public.user_data(userid);


--
-- Name: file_history file_history_fileid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_history
    ADD CONSTRAINT file_history_fileid_fkey FOREIGN KEY (fileid) REFERENCES public.file_data(fileid);


--
-- Name: file_history file_history_threadid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_history
    ADD CONSTRAINT file_history_threadid_fkey FOREIGN KEY (threadid) REFERENCES public.threads(threadid);


--
-- Name: file_notes_signatures file_notes_signatures_fileid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_notes_signatures
    ADD CONSTRAINT file_notes_signatures_fileid_fkey FOREIGN KEY (fileid) REFERENCES public.file_data(fileid);


--
-- Name: file_notes_signatures file_notes_signatures_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_notes_signatures
    ADD CONSTRAINT file_notes_signatures_userid_fkey FOREIGN KEY (userid) REFERENCES public.user_data(userid);


--
-- Name: file_signatures file_signatures_fileid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_signatures
    ADD CONSTRAINT file_signatures_fileid_fkey FOREIGN KEY (fileid) REFERENCES public.file_data(fileid);


--
-- Name: file_signatures file_signatures_signing_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file_signatures
    ADD CONSTRAINT file_signatures_signing_userid_fkey FOREIGN KEY (signing_userid) REFERENCES public.user_data(userid);


--
-- Name: live_notifications live_notifications_fileid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_notifications
    ADD CONSTRAINT live_notifications_fileid_fkey FOREIGN KEY (fileid) REFERENCES public.file_data(fileid);


--
-- Name: live_notifications live_notifications_orgid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_notifications
    ADD CONSTRAINT live_notifications_orgid_fkey FOREIGN KEY (orgid) REFERENCES public.organizations(orgid);


--
-- Name: live_notifications live_notifications_src_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_notifications
    ADD CONSTRAINT live_notifications_src_userid_fkey FOREIGN KEY (src_userid) REFERENCES public.user_data(userid);


--
-- Name: live_notifications live_notifications_target_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_notifications
    ADD CONSTRAINT live_notifications_target_userid_fkey FOREIGN KEY (target_userid) REFERENCES public.user_data(userid);


--
-- Name: live_notifications live_notifications_teamid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_notifications
    ADD CONSTRAINT live_notifications_teamid_fkey FOREIGN KEY (teamid) REFERENCES public.teams(teamid);


--
-- Name: live_notifications live_notifications_threadid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_notifications
    ADD CONSTRAINT live_notifications_threadid_fkey FOREIGN KEY (threadid) REFERENCES public.threads(threadid);


--
-- Name: notices notices_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notices
    ADD CONSTRAINT notices_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.user_data(userid);


--
-- Name: notices notices_related_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notices
    ADD CONSTRAINT notices_related_file_id_fkey FOREIGN KEY (related_file_id) REFERENCES public.file_data(fileid);


--
-- Name: forum_posts public_forum_posts_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT public_forum_posts_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.user_data(userid);


--
-- Name: forum_posts public_forum_posts_forumid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forum_posts
    ADD CONSTRAINT public_forum_posts_forumid_fkey FOREIGN KEY (forumid) REFERENCES public.forums(forumid);


--
-- Name: forums public_forums_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forums
    ADD CONSTRAINT public_forums_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.user_data(userid);


--
-- Name: thread_at_team public_thread_at_team_teamid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thread_at_team
    ADD CONSTRAINT public_thread_at_team_teamid_fkey FOREIGN KEY (teamid) REFERENCES public.teams(teamid);


--
-- Name: thread_at_team public_thread_at_team_threadid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.thread_at_team
    ADD CONSTRAINT public_thread_at_team_threadid_fkey FOREIGN KEY (threadid) REFERENCES public.threads(threadid);


--
-- Name: user_notices_list public_user_notices_list_noticeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notices_list
    ADD CONSTRAINT public_user_notices_list_noticeid_fkey FOREIGN KEY (noticeid) REFERENCES public.notices(noticeid);


--
-- Name: user_notices_list public_user_notices_list_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_notices_list
    ADD CONSTRAINT public_user_notices_list_userid_fkey FOREIGN KEY (userid) REFERENCES public.user_data(userid);


--
-- Name: teams teams_parent_orgid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_parent_orgid_fkey FOREIGN KEY (parent_orgid) REFERENCES public.organizations(orgid);


--
-- Name: threads threads_parent_teamid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.threads
    ADD CONSTRAINT threads_parent_teamid_fkey FOREIGN KEY (parent_teamid) REFERENCES public.teams(teamid);


--
-- Name: user_at_orgs user_at_orgs_orgid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_at_orgs
    ADD CONSTRAINT user_at_orgs_orgid_fkey FOREIGN KEY (orgid) REFERENCES public.organizations(orgid);


--
-- Name: user_at_teams user_at_teams_teamid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_at_teams
    ADD CONSTRAINT user_at_teams_teamid_fkey FOREIGN KEY (teamid) REFERENCES public.teams(teamid);


--
-- Name: user_at_threads user_at_threads_threadid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_at_threads
    ADD CONSTRAINT user_at_threads_threadid_fkey FOREIGN KEY (threadid) REFERENCES public.threads(threadid);


--
-- Name: user_at_threads user_at_threads_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_at_threads
    ADD CONSTRAINT user_at_threads_userid_fkey FOREIGN KEY (userid) REFERENCES public.user_data(userid);


--
-- Name: user_devices user_devices_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_userid_fkey FOREIGN KEY (userid) REFERENCES public.user_data(userid);


--
-- Name: user_publickey_history user_publickey_history_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_publickey_history
    ADD CONSTRAINT user_publickey_history_userid_fkey FOREIGN KEY (userid) REFERENCES public.user_data(userid);


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: file_data Enable read access for all users; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Enable read access for all users" ON public.file_data FOR SELECT TO authenticated, anon USING (true);


--
-- Name: user_at_orgs delete access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "delete access to anon, authenticated" ON public.user_at_orgs FOR DELETE TO authenticated, anon USING (true);


--
-- Name: user_at_teams delete access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "delete access to anon, authenticated" ON public.user_at_teams FOR DELETE TO authenticated, anon USING (true);


--
-- Name: user_at_threads delete access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "delete access to anon, authenticated" ON public.user_at_threads FOR DELETE TO authenticated, anon USING (true);


--
-- Name: file_at_org; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.file_at_org ENABLE ROW LEVEL SECURITY;

--
-- Name: file_at_team; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.file_at_team ENABLE ROW LEVEL SECURITY;

--
-- Name: file_at_thread; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.file_at_thread ENABLE ROW LEVEL SECURITY;

--
-- Name: file_data; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.file_data ENABLE ROW LEVEL SECURITY;

--
-- Name: file_history; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.file_history ENABLE ROW LEVEL SECURITY;

--
-- Name: file_notes_signatures; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.file_notes_signatures ENABLE ROW LEVEL SECURITY;

--
-- Name: file_signatures; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.file_signatures ENABLE ROW LEVEL SECURITY;

--
-- Name: forum_posts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.forum_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: forums; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.forums ENABLE ROW LEVEL SECURITY;

--
-- Name: file_data give insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "give insert access to anon, authenticated" ON public.file_data FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: file_signatures give insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "give insert access to anon, authenticated" ON public.file_signatures FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: user_data give insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "give insert access to anon, authenticated" ON public.user_data FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: user_devices give insert to anon, authenticatedtr; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "give insert to anon, authenticatedtr" ON public.user_devices FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: user_data give select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "give select access to anon, authenticated" ON public.user_data FOR SELECT TO authenticated, anon USING (true);


--
-- Name: file_signatures give select to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "give select to anon, authenticated" ON public.file_signatures FOR SELECT TO authenticated, anon USING (true);


--
-- Name: user_devices give select to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "give select to anon, authenticated" ON public.user_devices FOR SELECT TO authenticated, anon USING (true);


--
-- Name: forums insert access to anon and authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon and authenticated" ON public.forums FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: file_at_org insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.file_at_org FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: file_at_team insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.file_at_team FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: file_at_thread insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.file_at_thread FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: file_history insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.file_history FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: file_notes_signatures insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.file_notes_signatures FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: forum_posts insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.forum_posts FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: live_notifications insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.live_notifications FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: notices insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.notices FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: organizations insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.organizations FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: teams insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.teams FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: thread_at_team insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.thread_at_team FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: threads insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.threads FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: user_at_orgs insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.user_at_orgs FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: user_at_threads insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.user_at_threads FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: user_notices_list insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.user_notices_list FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: user_publickey_history insert access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated" ON public.user_publickey_history FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: user_at_teams insert access to anon, authenticated ; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "insert access to anon, authenticated " ON public.user_at_teams FOR INSERT TO authenticated, anon WITH CHECK (true);


--
-- Name: live_notifications; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.live_notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notices; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.notices ENABLE ROW LEVEL SECURITY;

--
-- Name: organizations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;

--
-- Name: user_at_orgs select access at anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access at anon, authenticated" ON public.user_at_orgs FOR SELECT TO authenticated, anon USING (true);


--
-- Name: forums select access to anon and authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon and authenticated" ON public.forums FOR SELECT TO authenticated, anon USING (true);


--
-- Name: file_at_org select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.file_at_org FOR SELECT TO authenticated, anon USING (true);


--
-- Name: file_at_team select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.file_at_team FOR SELECT TO authenticated, anon USING (true);


--
-- Name: file_at_thread select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.file_at_thread FOR SELECT TO authenticated, anon USING (true);


--
-- Name: file_history select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.file_history FOR SELECT TO authenticated, anon USING (true);


--
-- Name: file_notes_signatures select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.file_notes_signatures FOR SELECT TO authenticated, anon USING (true);


--
-- Name: forum_posts select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.forum_posts FOR SELECT TO authenticated, anon USING (true);


--
-- Name: live_notifications select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.live_notifications FOR SELECT TO authenticated, anon USING (true);


--
-- Name: notices select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.notices FOR SELECT TO authenticated, anon USING (true);


--
-- Name: organizations select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.organizations FOR SELECT TO authenticated, anon USING (true);


--
-- Name: teams select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.teams FOR SELECT TO authenticated, anon USING (true);


--
-- Name: thread_at_team select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.thread_at_team FOR SELECT TO authenticated, anon USING (true);


--
-- Name: threads select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.threads FOR SELECT TO authenticated, anon USING (true);


--
-- Name: user_at_teams select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.user_at_teams FOR SELECT TO authenticated, anon USING (true);


--
-- Name: user_at_threads select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.user_at_threads FOR SELECT TO authenticated, anon USING (true);


--
-- Name: user_notices_list select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.user_notices_list FOR SELECT TO authenticated, anon USING (true);


--
-- Name: user_publickey_history select access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "select access to anon, authenticated" ON public.user_publickey_history FOR SELECT TO authenticated, anon USING (true);


--
-- Name: teams; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;

--
-- Name: thread_at_team; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.thread_at_team ENABLE ROW LEVEL SECURITY;

--
-- Name: threads; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.threads ENABLE ROW LEVEL SECURITY;

--
-- Name: file_notes_signatures update access to ; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to " ON public.file_notes_signatures FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: forums update access to anon and authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon and authenticated" ON public.forums FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: live_notifications update access to anon, auth; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, auth" ON public.live_notifications FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: file_at_org update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.file_at_org FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: file_at_team update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.file_at_team FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: file_at_thread update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.file_at_thread FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: file_data update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.file_data FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: file_history update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.file_history FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: file_signatures update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.file_signatures FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: forum_posts update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.forum_posts FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: notices update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.notices FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: organizations update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.organizations FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: teams update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.teams FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: thread_at_team update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.thread_at_team FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: threads update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.threads FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: user_at_orgs update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.user_at_orgs FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: user_at_teams update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.user_at_teams FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: user_at_threads update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.user_at_threads FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: user_data update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.user_data FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: user_notices_list update access to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update access to anon, authenticated" ON public.user_notices_list FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: user_publickey_history update to anon, authenticated; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "update to anon, authenticated" ON public.user_publickey_history FOR UPDATE TO authenticated, anon USING (true) WITH CHECK (true);


--
-- Name: user_at_orgs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_at_orgs ENABLE ROW LEVEL SECURITY;

--
-- Name: user_at_teams; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_at_teams ENABLE ROW LEVEL SECURITY;

--
-- Name: user_at_threads; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_at_threads ENABLE ROW LEVEL SECURITY;

--
-- Name: user_data; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_data ENABLE ROW LEVEL SECURITY;

--
-- Name: user_devices; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_devices ENABLE ROW LEVEL SECURITY;

--
-- Name: user_notices_list; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_notices_list ENABLE ROW LEVEL SECURITY;

--
-- Name: user_publickey_history; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_publickey_history ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: objects select, insert, update access to anon, authentica 7rjxd8_0; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "select, insert, update access to anon, authentica 7rjxd8_0" ON storage.objects FOR SELECT TO authenticated, anon USING ((bucket_id = 'user_personal_files'::text));


--
-- Name: objects select, insert, update access to anon, authentica 7rjxd8_1; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "select, insert, update access to anon, authentica 7rjxd8_1" ON storage.objects FOR INSERT TO authenticated, anon WITH CHECK ((bucket_id = 'user_personal_files'::text));


--
-- Name: objects select, insert, update access to anon, authentica 7rjxd8_2; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "select, insert, update access to anon, authentica 7rjxd8_2" ON storage.objects FOR UPDATE TO authenticated, anon USING ((bucket_id = 'user_personal_files'::text));


--
-- Name: objects select, insert, update access to anon, authenticat 1m0cqf_0; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "select, insert, update access to anon, authenticat 1m0cqf_0" ON storage.objects FOR UPDATE TO authenticated, anon USING ((bucket_id = 'files'::text));


--
-- Name: objects select, insert, update access to anon, authenticat 1m0cqf_1; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "select, insert, update access to anon, authenticat 1m0cqf_1" ON storage.objects FOR INSERT TO authenticated, anon WITH CHECK ((bucket_id = 'files'::text));


--
-- Name: objects select, insert, update access to anon, authenticat 1m0cqf_2; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "select, insert, update access to anon, authenticat 1m0cqf_2" ON storage.objects FOR SELECT TO authenticated, anon USING ((bucket_id = 'files'::text));


--
-- Name: objects select, insert, update access to anon, authenticat 5m2mwd_0; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "select, insert, update access to anon, authenticat 5m2mwd_0" ON storage.objects FOR SELECT TO authenticated, anon USING ((bucket_id = 'user_pfps'::text));


--
-- Name: objects select, insert, update access to anon, authenticat 5m2mwd_1; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "select, insert, update access to anon, authenticat 5m2mwd_1" ON storage.objects FOR UPDATE TO authenticated, anon USING ((bucket_id = 'user_pfps'::text));


--
-- Name: objects select, insert, update access to anon, authenticat 5m2mwd_2; Type: POLICY; Schema: storage; Owner: supabase_storage_admin
--

CREATE POLICY "select, insert, update access to anon, authenticat 5m2mwd_2" ON storage.objects FOR INSERT TO authenticated, anon WITH CHECK ((bucket_id = 'user_pfps'::text));


--
-- Name: DATABASE postgres; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE postgres TO dashboard_user;
GRANT CREATE ON DATABASE postgres TO anon;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT ALL ON SCHEMA storage TO postgres;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM postgres;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION add_child_post(given_creator_id uuid, given_content text, given_parent_id uuid, given_forumid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_child_post(given_creator_id uuid, given_content text, given_parent_id uuid, given_forumid uuid) TO anon;
GRANT ALL ON FUNCTION public.add_child_post(given_creator_id uuid, given_content text, given_parent_id uuid, given_forumid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.add_child_post(given_creator_id uuid, given_content text, given_parent_id uuid, given_forumid uuid) TO service_role;


--
-- Name: FUNCTION add_file_note(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text, given_content text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_file_note(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text, given_content text) TO anon;
GRANT ALL ON FUNCTION public.add_file_note(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text, given_content text) TO authenticated;
GRANT ALL ON FUNCTION public.add_file_note(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text, given_content text) TO service_role;


--
-- Name: FUNCTION add_forum_thread(given_creator_id uuid, given_forum_thread_name text, given_forum_subject text, given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_forum_thread(given_creator_id uuid, given_forum_thread_name text, given_forum_subject text, given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid) TO anon;
GRANT ALL ON FUNCTION public.add_forum_thread(given_creator_id uuid, given_forum_thread_name text, given_forum_subject text, given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.add_forum_thread(given_creator_id uuid, given_forum_thread_name text, given_forum_subject text, given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid) TO service_role;


--
-- Name: FUNCTION add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid) TO anon;
GRANT ALL ON FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid) TO service_role;


--
-- Name: FUNCTION add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid, given_fileid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid, given_fileid uuid) TO anon;
GRANT ALL ON FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid, given_fileid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.add_notice(given_creator_id uuid, given_hierarchy_level public.hierarchy_level_name, given_subject text, given_content text, given_hierarchy_level_id uuid, given_fileid uuid) TO service_role;


--
-- Name: FUNCTION add_notice_file(given_file_ownerid uuid, given_noticeid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_notice_file(given_file_ownerid uuid, given_noticeid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO anon;
GRANT ALL ON FUNCTION public.add_notice_file(given_file_ownerid uuid, given_noticeid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO authenticated;
GRANT ALL ON FUNCTION public.add_notice_file(given_file_ownerid uuid, given_noticeid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO service_role;


--
-- Name: FUNCTION add_org_file(given_file_ownerid uuid, given_orgid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_org_file(given_file_ownerid uuid, given_orgid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO anon;
GRANT ALL ON FUNCTION public.add_org_file(given_file_ownerid uuid, given_orgid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO authenticated;
GRANT ALL ON FUNCTION public.add_org_file(given_file_ownerid uuid, given_orgid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO service_role;


--
-- Name: FUNCTION add_org_member(given_orgid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_org_member(given_orgid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) TO anon;
GRANT ALL ON FUNCTION public.add_org_member(given_orgid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) TO authenticated;
GRANT ALL ON FUNCTION public.add_org_member(given_orgid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) TO service_role;


--
-- Name: FUNCTION add_personal_file(given_file_ownerid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_personal_file(given_file_ownerid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO anon;
GRANT ALL ON FUNCTION public.add_personal_file(given_file_ownerid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO authenticated;
GRANT ALL ON FUNCTION public.add_personal_file(given_file_ownerid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO service_role;


--
-- Name: FUNCTION add_personal_file_signature(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_personal_file_signature(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text) TO anon;
GRANT ALL ON FUNCTION public.add_personal_file_signature(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text) TO authenticated;
GRANT ALL ON FUNCTION public.add_personal_file_signature(given_fileid uuid, given_signing_userid uuid, given_signature text, given_signing_key text) TO service_role;


--
-- Name: FUNCTION add_publickey_user(given_userid uuid, given_publickey text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_publickey_user(given_userid uuid, given_publickey text) TO anon;
GRANT ALL ON FUNCTION public.add_publickey_user(given_userid uuid, given_publickey text) TO authenticated;
GRANT ALL ON FUNCTION public.add_publickey_user(given_userid uuid, given_publickey text) TO service_role;


--
-- Name: FUNCTION add_team_file(given_file_ownerid uuid, given_teamid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_team_file(given_file_ownerid uuid, given_teamid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO anon;
GRANT ALL ON FUNCTION public.add_team_file(given_file_ownerid uuid, given_teamid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO authenticated;
GRANT ALL ON FUNCTION public.add_team_file(given_file_ownerid uuid, given_teamid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO service_role;


--
-- Name: FUNCTION add_team_member(given_teamid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_team_member(given_teamid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) TO anon;
GRANT ALL ON FUNCTION public.add_team_member(given_teamid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) TO authenticated;
GRANT ALL ON FUNCTION public.add_team_member(given_teamid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_user_post text) TO service_role;


--
-- Name: FUNCTION add_thread_file(given_file_ownerid uuid, given_threadid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_thread_file(given_file_ownerid uuid, given_threadid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO anon;
GRANT ALL ON FUNCTION public.add_thread_file(given_file_ownerid uuid, given_threadid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO authenticated;
GRANT ALL ON FUNCTION public.add_thread_file(given_file_ownerid uuid, given_threadid uuid, given_file_url text, given_filename text, given_file_extension text, given_file_mimetype integer) TO service_role;


--
-- Name: FUNCTION add_thread_member(given_threadid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_signing_serial integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_thread_member(given_threadid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_signing_serial integer) TO anon;
GRANT ALL ON FUNCTION public.add_thread_member(given_threadid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_signing_serial integer) TO authenticated;
GRANT ALL ON FUNCTION public.add_thread_member(given_threadid uuid, given_userid uuid, current_userid uuid, given_user_role public.member_level_name, given_signing_serial integer) TO service_role;


--
-- Name: FUNCTION add_thread_passive_member(given_threadid uuid, given_userid uuid, current_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_thread_passive_member(given_threadid uuid, given_userid uuid, current_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.add_thread_passive_member(given_threadid uuid, given_userid uuid, current_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.add_thread_passive_member(given_threadid uuid, given_userid uuid, current_userid uuid) TO service_role;


--
-- Name: FUNCTION add_thread_to_team(given_threadid uuid, given_teamid uuid, given_is_parent boolean); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_thread_to_team(given_threadid uuid, given_teamid uuid, given_is_parent boolean) TO anon;
GRANT ALL ON FUNCTION public.add_thread_to_team(given_threadid uuid, given_teamid uuid, given_is_parent boolean) TO authenticated;
GRANT ALL ON FUNCTION public.add_thread_to_team(given_threadid uuid, given_teamid uuid, given_is_parent boolean) TO service_role;


--
-- Name: FUNCTION add_top_post(given_creator_id uuid, given_title text, given_content text, given_forumid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_top_post(given_creator_id uuid, given_title text, given_content text, given_forumid uuid) TO anon;
GRANT ALL ON FUNCTION public.add_top_post(given_creator_id uuid, given_title text, given_content text, given_forumid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.add_top_post(given_creator_id uuid, given_title text, given_content text, given_forumid uuid) TO service_role;


--
-- Name: FUNCTION add_user(given_username text, given_email text, given_pwd_hash text, given_publickey text, given_pfp_url text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.add_user(given_username text, given_email text, given_pwd_hash text, given_publickey text, given_pfp_url text) TO anon;
GRANT ALL ON FUNCTION public.add_user(given_username text, given_email text, given_pwd_hash text, given_publickey text, given_pfp_url text) TO authenticated;
GRANT ALL ON FUNCTION public.add_user(given_username text, given_email text, given_pwd_hash text, given_publickey text, given_pfp_url text) TO service_role;


--
-- Name: FUNCTION are_there_notifications(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.are_there_notifications(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.are_there_notifications(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.are_there_notifications(given_userid uuid) TO service_role;


--
-- Name: FUNCTION can_add_file_thread(given_userid uuid, given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_add_file_thread(given_userid uuid, given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.can_add_file_thread(given_userid uuid, given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.can_add_file_thread(given_userid uuid, given_threadid uuid) TO service_role;


--
-- Name: FUNCTION can_add_user_to_org(given_orgid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_add_user_to_org(given_orgid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.can_add_user_to_org(given_orgid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.can_add_user_to_org(given_orgid uuid, given_userid uuid) TO service_role;


--
-- Name: FUNCTION can_add_user_to_team(given_teamid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_add_user_to_team(given_teamid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.can_add_user_to_team(given_teamid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.can_add_user_to_team(given_teamid uuid, given_userid uuid) TO service_role;


--
-- Name: FUNCTION can_add_user_to_thread(given_threadid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_add_user_to_thread(given_threadid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.can_add_user_to_thread(given_threadid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.can_add_user_to_thread(given_threadid uuid, given_userid uuid) TO service_role;


--
-- Name: FUNCTION can_close_thread(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_close_thread(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.can_close_thread(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.can_close_thread(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION can_force_forward_thread(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_force_forward_thread(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.can_force_forward_thread(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.can_force_forward_thread(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION can_forward_thread(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_forward_thread(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.can_forward_thread(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.can_forward_thread(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION can_forward_thread2(given_threadid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_forward_thread2(given_threadid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.can_forward_thread2(given_threadid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.can_forward_thread2(given_threadid uuid, given_userid uuid) TO service_role;


--
-- Name: FUNCTION can_leave_org(given_orgid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_leave_org(given_orgid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.can_leave_org(given_orgid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.can_leave_org(given_orgid uuid, given_userid uuid) TO service_role;


--
-- Name: TABLE user_data; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_data TO anon;
GRANT ALL ON TABLE public.user_data TO authenticated;
GRANT ALL ON TABLE public.user_data TO service_role;


--
-- Name: FUNCTION can_log_in_user(given_email text, given_pwd_hash text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_log_in_user(given_email text, given_pwd_hash text) TO anon;
GRANT ALL ON FUNCTION public.can_log_in_user(given_email text, given_pwd_hash text) TO authenticated;
GRANT ALL ON FUNCTION public.can_log_in_user(given_email text, given_pwd_hash text) TO service_role;


--
-- Name: FUNCTION can_log_in_user_boolean(given_email text, given_pwd_hash text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_log_in_user_boolean(given_email text, given_pwd_hash text) TO anon;
GRANT ALL ON FUNCTION public.can_log_in_user_boolean(given_email text, given_pwd_hash text) TO authenticated;
GRANT ALL ON FUNCTION public.can_log_in_user_boolean(given_email text, given_pwd_hash text) TO service_role;


--
-- Name: FUNCTION can_log_in_user_errorcode(given_email text, given_pwd_hash text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_log_in_user_errorcode(given_email text, given_pwd_hash text) TO anon;
GRANT ALL ON FUNCTION public.can_log_in_user_errorcode(given_email text, given_pwd_hash text) TO authenticated;
GRANT ALL ON FUNCTION public.can_log_in_user_errorcode(given_email text, given_pwd_hash text) TO service_role;


--
-- Name: FUNCTION can_signup_user(given_email text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.can_signup_user(given_email text) TO anon;
GRANT ALL ON FUNCTION public.can_signup_user(given_email text) TO authenticated;
GRANT ALL ON FUNCTION public.can_signup_user(given_email text) TO service_role;


--
-- Name: FUNCTION create_org(given_orgname text, given_description text, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.create_org(given_orgname text, given_description text, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.create_org(given_orgname text, given_description text, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.create_org(given_orgname text, given_description text, given_userid uuid) TO service_role;


--
-- Name: FUNCTION create_team(given_parent_orgid uuid, given_teamname text, given_description text, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.create_team(given_parent_orgid uuid, given_teamname text, given_description text, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.create_team(given_parent_orgid uuid, given_teamname text, given_description text, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.create_team(given_parent_orgid uuid, given_teamname text, given_description text, given_userid uuid) TO service_role;


--
-- Name: FUNCTION create_thread(given_threadname text, given_parent_teamid uuid, given_description text, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.create_thread(given_threadname text, given_parent_teamid uuid, given_description text, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.create_thread(given_threadname text, given_parent_teamid uuid, given_description text, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.create_thread(given_threadname text, given_parent_teamid uuid, given_description text, given_userid uuid) TO service_role;


--
-- Name: FUNCTION edit_passwd(given_userid uuid, given_new_pwd_hash text, given_old_pwd_hash text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.edit_passwd(given_userid uuid, given_new_pwd_hash text, given_old_pwd_hash text) TO anon;
GRANT ALL ON FUNCTION public.edit_passwd(given_userid uuid, given_new_pwd_hash text, given_old_pwd_hash text) TO authenticated;
GRANT ALL ON FUNCTION public.edit_passwd(given_userid uuid, given_new_pwd_hash text, given_old_pwd_hash text) TO service_role;


--
-- Name: FUNCTION edit_profile(given_userid uuid, given_username text, given_email text, given_pwd_hash text, given_pfp_url text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.edit_profile(given_userid uuid, given_username text, given_email text, given_pwd_hash text, given_pfp_url text) TO anon;
GRANT ALL ON FUNCTION public.edit_profile(given_userid uuid, given_username text, given_email text, given_pwd_hash text, given_pfp_url text) TO authenticated;
GRANT ALL ON FUNCTION public.edit_profile(given_userid uuid, given_username text, given_email text, given_pwd_hash text, given_pfp_url text) TO service_role;


--
-- Name: FUNCTION force_forward_thread(given_threadid uuid, given_src_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.force_forward_thread(given_threadid uuid, given_src_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.force_forward_thread(given_threadid uuid, given_src_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.force_forward_thread(given_threadid uuid, given_src_userid uuid) TO service_role;


--
-- Name: FUNCTION forward_thread(given_threadid uuid, given_src_userid uuid, given_target_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.forward_thread(given_threadid uuid, given_src_userid uuid, given_target_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.forward_thread(given_threadid uuid, given_src_userid uuid, given_target_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.forward_thread(given_threadid uuid, given_src_userid uuid, given_target_userid uuid) TO service_role;


--
-- Name: FUNCTION forward_thread_file(given_threadid uuid, given_fileid uuid, given_src_userid uuid, given_target_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.forward_thread_file(given_threadid uuid, given_fileid uuid, given_src_userid uuid, given_target_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.forward_thread_file(given_threadid uuid, given_fileid uuid, given_src_userid uuid, given_target_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.forward_thread_file(given_threadid uuid, given_fileid uuid, given_src_userid uuid, given_target_userid uuid) TO service_role;


--
-- Name: FUNCTION get_all_orgs(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_all_orgs() TO anon;
GRANT ALL ON FUNCTION public.get_all_orgs() TO authenticated;
GRANT ALL ON FUNCTION public.get_all_orgs() TO service_role;


--
-- Name: FUNCTION get_current_signing_serial(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_current_signing_serial(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_current_signing_serial(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_current_signing_serial(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_file_data_39(owner_id uuid, type text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_file_data_39(owner_id uuid, type text) TO anon;
GRANT ALL ON FUNCTION public.get_file_data_39(owner_id uuid, type text) TO authenticated;
GRANT ALL ON FUNCTION public.get_file_data_39(owner_id uuid, type text) TO service_role;


--
-- Name: FUNCTION get_file_history_fileid(given_fileid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_file_history_fileid(given_fileid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_file_history_fileid(given_fileid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_file_history_fileid(given_fileid uuid) TO service_role;


--
-- Name: FUNCTION get_file_signatures_fileid(given_fileid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_file_signatures_fileid(given_fileid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_file_signatures_fileid(given_fileid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_file_signatures_fileid(given_fileid uuid) TO service_role;


--
-- Name: FUNCTION get_forum_metadata(given_forumid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_forum_metadata(given_forumid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_forum_metadata(given_forumid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_forum_metadata(given_forumid uuid) TO service_role;


--
-- Name: FUNCTION get_forum_top_level_posts(given_forumid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_forum_top_level_posts(given_forumid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_forum_top_level_posts(given_forumid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_forum_top_level_posts(given_forumid uuid) TO service_role;


--
-- Name: FUNCTION get_hierarchy_all_forum_metadata(given_uid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_hierarchy_all_forum_metadata(given_uid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_hierarchy_all_forum_metadata(given_uid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_hierarchy_all_forum_metadata(given_uid uuid) TO service_role;


--
-- Name: FUNCTION get_notice_recipient_list(given_noticeid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_notice_recipient_list(given_noticeid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_notice_recipient_list(given_noticeid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_notice_recipient_list(given_noticeid uuid) TO service_role;


--
-- Name: FUNCTION get_notice_scope_entity_details(given_noticeid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_notice_scope_entity_details(given_noticeid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_notice_scope_entity_details(given_noticeid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_notice_scope_entity_details(given_noticeid uuid) TO service_role;


--
-- Name: FUNCTION get_notice_seen_recipient_list(given_noticeid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_notice_seen_recipient_list(given_noticeid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_notice_seen_recipient_list(given_noticeid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_notice_seen_recipient_list(given_noticeid uuid) TO service_role;


--
-- Name: FUNCTION get_notice_unseen_recipient_list(given_noticeid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_notice_unseen_recipient_list(given_noticeid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_notice_unseen_recipient_list(given_noticeid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_notice_unseen_recipient_list(given_noticeid uuid) TO service_role;


--
-- Name: FUNCTION get_noticedetails(given_noticeid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_noticedetails(given_noticeid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_noticedetails(given_noticeid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_noticedetails(given_noticeid uuid) TO service_role;


--
-- Name: FUNCTION get_org_active_threads(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_active_threads(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_active_threads(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_active_threads(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_addable_member_list(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_addable_member_list(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_addable_member_list(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_addable_member_list(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_all_notice(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_all_notice(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_all_notice(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_all_notice(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_all_threads(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_all_threads(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_all_threads(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_all_threads(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_details(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_details(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_details(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_details(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_file_list(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_file_list(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_file_list(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_file_list(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_member_list(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_member_list(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_member_list(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_member_list(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_mods_details(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_mods_details(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_mods_details(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_mods_details(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_seen_notice(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_seen_notice(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_seen_notice(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_seen_notice(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_team_list(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_team_list(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_team_list(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_team_list(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_threads(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_threads(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_threads(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_threads(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_threads_count(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_threads_count(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_threads_count(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_threads_count(given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_org_unseen_notice(given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_org_unseen_notice(given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_org_unseen_notice(given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_org_unseen_notice(given_orgid uuid) TO service_role;


--
-- Name: TABLE file_signatures; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.file_signatures TO anon;
GRANT ALL ON TABLE public.file_signatures TO authenticated;
GRANT ALL ON TABLE public.file_signatures TO service_role;


--
-- Name: FUNCTION get_personal_file_signatures_fileid(given_fileid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_personal_file_signatures_fileid(given_fileid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_personal_file_signatures_fileid(given_fileid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_personal_file_signatures_fileid(given_fileid uuid, given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_post(given_postid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_post(given_postid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_post(given_postid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_post(given_postid uuid) TO service_role;


--
-- Name: TABLE file_data; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.file_data TO anon;
GRANT ALL ON TABLE public.file_data TO authenticated;
GRANT ALL ON TABLE public.file_data TO service_role;


--
-- Name: FUNCTION get_single_filedata_fileid(given_fileid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_single_filedata_fileid(given_fileid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_single_filedata_fileid(given_fileid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_single_filedata_fileid(given_fileid uuid, given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_single_filemetadata_fileid(given_fileid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_single_filemetadata_fileid(given_fileid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_single_filemetadata_fileid(given_fileid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_single_filemetadata_fileid(given_fileid uuid) TO service_role;


--
-- Name: FUNCTION get_team_active_thread_list(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_active_thread_list(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_active_thread_list(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_active_thread_list(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_addable_member_list(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_addable_member_list(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_addable_member_list(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_addable_member_list(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_all_notice(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_all_notice(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_all_notice(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_all_notice(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_archived_thread_list(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_archived_thread_list(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_archived_thread_list(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_archived_thread_list(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_details(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_details(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_details(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_details(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_file_list(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_file_list(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_file_list(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_file_list(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_member_list(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_member_list(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_member_list(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_member_list(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_mods_details(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_mods_details(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_mods_details(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_mods_details(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_seen_notice(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_seen_notice(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_seen_notice(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_seen_notice(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_thread_list(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_thread_list(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_thread_list(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_thread_list(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_team_unseen_notice(given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_team_unseen_notice(given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_team_unseen_notice(given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_team_unseen_notice(given_teamid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_addable_member_list(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_addable_member_list(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_addable_member_list(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_addable_member_list(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_addable_member_list2(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_addable_member_list2(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_addable_member_list2(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_addable_member_list2(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_all_notice(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_all_notice(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_all_notice(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_all_notice(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_details(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_details(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_details(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_details(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_file_list(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_file_list(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_file_list(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_file_list(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_forwardable_members(given_threadid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_forwardable_members(given_threadid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_forwardable_members(given_threadid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_forwardable_members(given_threadid uuid, given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_member_list(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_member_list(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_member_list(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_member_list(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_mods_details(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_mods_details(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_mods_details(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_mods_details(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_seen_notice(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_seen_notice(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_seen_notice(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_seen_notice(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_thread_unseen_notice(given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_thread_unseen_notice(given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_thread_unseen_notice(given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_thread_unseen_notice(given_threadid uuid) TO service_role;


--
-- Name: FUNCTION get_threadfile_notes_list(given_fileid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_threadfile_notes_list(given_fileid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_threadfile_notes_list(given_fileid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_threadfile_notes_list(given_fileid uuid) TO service_role;


--
-- Name: FUNCTION get_threadfile_notes_list2(given_fileid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_threadfile_notes_list2(given_fileid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_threadfile_notes_list2(given_fileid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_threadfile_notes_list2(given_fileid uuid) TO service_role;


--
-- Name: FUNCTION get_user_active_threads(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_active_threads(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_active_threads(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_active_threads(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_all_notice(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_all_notice(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_all_notice(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_all_notice(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_all_publickey_userid(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_all_publickey_userid(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_all_publickey_userid(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_all_publickey_userid(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_all_threads(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_all_threads(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_all_threads(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_all_threads(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_archived_threads(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_archived_threads(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_archived_threads(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_archived_threads(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_detail_pubkey(given_pubkey text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_detail_pubkey(given_pubkey text) TO anon;
GRANT ALL ON FUNCTION public.get_user_detail_pubkey(given_pubkey text) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_detail_pubkey(given_pubkey text) TO service_role;


--
-- Name: FUNCTION get_user_details_email(given_email text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_details_email(given_email text) TO anon;
GRANT ALL ON FUNCTION public.get_user_details_email(given_email text) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_details_email(given_email text) TO service_role;


--
-- Name: FUNCTION get_user_details_email2(given_email text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_details_email2(given_email text) TO anon;
GRANT ALL ON FUNCTION public.get_user_details_email2(given_email text) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_details_email2(given_email text) TO service_role;


--
-- Name: FUNCTION get_user_details_userid(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_details_userid(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_details_userid(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_details_userid(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_live_notifications(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_live_notifications(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_live_notifications(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_live_notifications(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_org_detail_pubkey(given_pubkey text, given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_org_detail_pubkey(given_pubkey text, given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_org_detail_pubkey(given_pubkey text, given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_org_detail_pubkey(given_pubkey text, given_orgid uuid) TO service_role;


--
-- Name: FUNCTION get_user_orgs_userid(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_orgs_userid(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_orgs_userid(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_orgs_userid(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_personal_file_single_userid(given_userid uuid, given_fileid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_personal_file_single_userid(given_userid uuid, given_fileid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_personal_file_single_userid(given_userid uuid, given_fileid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_personal_file_single_userid(given_userid uuid, given_fileid uuid) TO service_role;


--
-- Name: FUNCTION get_user_personal_files_by_type_userid_mohaimin(given_userid uuid, given_file_extension text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_personal_files_by_type_userid_mohaimin(given_userid uuid, given_file_extension text) TO anon;
GRANT ALL ON FUNCTION public.get_user_personal_files_by_type_userid_mohaimin(given_userid uuid, given_file_extension text) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_personal_files_by_type_userid_mohaimin(given_userid uuid, given_file_extension text) TO service_role;


--
-- Name: FUNCTION get_user_personal_files_by_type_userid_sadif(given_userid uuid, given_file_extension text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_personal_files_by_type_userid_sadif(given_userid uuid, given_file_extension text) TO anon;
GRANT ALL ON FUNCTION public.get_user_personal_files_by_type_userid_sadif(given_userid uuid, given_file_extension text) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_personal_files_by_type_userid_sadif(given_userid uuid, given_file_extension text) TO service_role;


--
-- Name: FUNCTION get_user_personal_files_userid(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_personal_files_userid(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_personal_files_userid(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_personal_files_userid(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_publickey_userid(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_publickey_userid(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_publickey_userid(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_publickey_userid(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_seen_notice(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_seen_notice(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_seen_notice(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_seen_notice(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_team_from_org(given_orgid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_team_from_org(given_orgid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_team_from_org(given_orgid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_team_from_org(given_orgid uuid, given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_teams_userid(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_teams_userid(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_teams_userid(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_teams_userid(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_unseen_notice(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_unseen_notice(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_unseen_notice(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_unseen_notice(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_unsent_notifications(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_unsent_notifications(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_unsent_notifications(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_unsent_notifications(given_userid uuid) TO service_role;


--
-- Name: FUNCTION get_user_workfiles_userid(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_workfiles_userid(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.get_user_workfiles_userid(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.get_user_workfiles_userid(given_userid uuid) TO service_role;


--
-- Name: FUNCTION is_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.is_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.is_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.is_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) TO service_role;


--
-- Name: FUNCTION is_member_of(given_userid uuid, given_hierarchy_id uuid, given_hierarchy_name public.hierarchy_level_name); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.is_member_of(given_userid uuid, given_hierarchy_id uuid, given_hierarchy_name public.hierarchy_level_name) TO anon;
GRANT ALL ON FUNCTION public.is_member_of(given_userid uuid, given_hierarchy_id uuid, given_hierarchy_name public.hierarchy_level_name) TO authenticated;
GRANT ALL ON FUNCTION public.is_member_of(given_userid uuid, given_hierarchy_id uuid, given_hierarchy_name public.hierarchy_level_name) TO service_role;


--
-- Name: FUNCTION is_notice_seen(given_noticeid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.is_notice_seen(given_noticeid uuid) TO anon;
GRANT ALL ON FUNCTION public.is_notice_seen(given_noticeid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.is_notice_seen(given_noticeid uuid) TO service_role;


--
-- Name: FUNCTION leave_org(given_orgid uuid, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.leave_org(given_orgid uuid, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.leave_org(given_orgid uuid, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.leave_org(given_orgid uuid, given_userid uuid) TO service_role;


--
-- Name: FUNCTION make_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.make_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.make_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.make_admin(given_hierarchy_level public.hierarchy_level_name, given_hierarchy_level_id uuid, target_userid uuid) TO service_role;


--
-- Name: FUNCTION make_thread_archived(given_threadid uuid, given_closing_comment text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.make_thread_archived(given_threadid uuid, given_closing_comment text) TO anon;
GRANT ALL ON FUNCTION public.make_thread_archived(given_threadid uuid, given_closing_comment text) TO authenticated;
GRANT ALL ON FUNCTION public.make_thread_archived(given_threadid uuid, given_closing_comment text) TO service_role;


--
-- Name: FUNCTION make_thread_archived(given_threadid uuid, given_current_userid uuid, given_closing_comment text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.make_thread_archived(given_threadid uuid, given_current_userid uuid, given_closing_comment text) TO anon;
GRANT ALL ON FUNCTION public.make_thread_archived(given_threadid uuid, given_current_userid uuid, given_closing_comment text) TO authenticated;
GRANT ALL ON FUNCTION public.make_thread_archived(given_threadid uuid, given_current_userid uuid, given_closing_comment text) TO service_role;


--
-- Name: FUNCTION make_threadfile_viewed_signed(given_current_userid uuid, given_fileid uuid, given_signature text, given_signing_key text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.make_threadfile_viewed_signed(given_current_userid uuid, given_fileid uuid, given_signature text, given_signing_key text) TO anon;
GRANT ALL ON FUNCTION public.make_threadfile_viewed_signed(given_current_userid uuid, given_fileid uuid, given_signature text, given_signing_key text) TO authenticated;
GRANT ALL ON FUNCTION public.make_threadfile_viewed_signed(given_current_userid uuid, given_fileid uuid, given_signature text, given_signing_key text) TO service_role;


--
-- Name: FUNCTION make_user_notice_seen(given_userid uuid, given_noticeid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.make_user_notice_seen(given_userid uuid, given_noticeid uuid) TO anon;
GRANT ALL ON FUNCTION public.make_user_notice_seen(given_userid uuid, given_noticeid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.make_user_notice_seen(given_userid uuid, given_noticeid uuid) TO service_role;


--
-- Name: FUNCTION search_notices(term text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_notices(term text) TO anon;
GRANT ALL ON FUNCTION public.search_notices(term text) TO authenticated;
GRANT ALL ON FUNCTION public.search_notices(term text) TO service_role;


--
-- Name: FUNCTION search_org_notices(term text, given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_org_notices(term text, given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_org_notices(term text, given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_org_notices(term text, given_orgid uuid) TO service_role;


--
-- Name: FUNCTION search_org_teams(term text, given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_org_teams(term text, given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_org_teams(term text, given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_org_teams(term text, given_orgid uuid) TO service_role;


--
-- Name: FUNCTION search_org_threads(term text, given_orgid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_org_threads(term text, given_orgid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_org_threads(term text, given_orgid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_org_threads(term text, given_orgid uuid) TO service_role;


--
-- Name: FUNCTION search_orgs(term text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_orgs(term text) TO anon;
GRANT ALL ON FUNCTION public.search_orgs(term text) TO authenticated;
GRANT ALL ON FUNCTION public.search_orgs(term text) TO service_role;


--
-- Name: FUNCTION search_team_file(term text, given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_team_file(term text, given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_team_file(term text, given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_team_file(term text, given_teamid uuid) TO service_role;


--
-- Name: FUNCTION search_team_notices(term text, given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_team_notices(term text, given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_team_notices(term text, given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_team_notices(term text, given_teamid uuid) TO service_role;


--
-- Name: FUNCTION search_team_threads(term text, given_teamid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_team_threads(term text, given_teamid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_team_threads(term text, given_teamid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_team_threads(term text, given_teamid uuid) TO service_role;


--
-- Name: FUNCTION search_teams(term text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_teams(term text) TO anon;
GRANT ALL ON FUNCTION public.search_teams(term text) TO authenticated;
GRANT ALL ON FUNCTION public.search_teams(term text) TO service_role;


--
-- Name: FUNCTION search_thread_file(term text, given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_thread_file(term text, given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_thread_file(term text, given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_thread_file(term text, given_threadid uuid) TO service_role;


--
-- Name: FUNCTION search_thread_notices(term text, given_threadid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_thread_notices(term text, given_threadid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_thread_notices(term text, given_threadid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_thread_notices(term text, given_threadid uuid) TO service_role;


--
-- Name: FUNCTION search_threads(term text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_threads(term text) TO anon;
GRANT ALL ON FUNCTION public.search_threads(term text) TO authenticated;
GRANT ALL ON FUNCTION public.search_threads(term text) TO service_role;


--
-- Name: FUNCTION search_user_by_name(term text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_user_by_name(term text) TO anon;
GRANT ALL ON FUNCTION public.search_user_by_name(term text) TO authenticated;
GRANT ALL ON FUNCTION public.search_user_by_name(term text) TO service_role;


--
-- Name: FUNCTION search_user_notices(term text, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_user_notices(term text, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_user_notices(term text, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_user_notices(term text, given_userid uuid) TO service_role;


--
-- Name: FUNCTION search_user_orgs(term text, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_user_orgs(term text, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_user_orgs(term text, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_user_orgs(term text, given_userid uuid) TO service_role;


--
-- Name: FUNCTION search_user_personal_file(term text, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_user_personal_file(term text, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_user_personal_file(term text, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_user_personal_file(term text, given_userid uuid) TO service_role;


--
-- Name: FUNCTION search_user_teams(term text, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_user_teams(term text, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_user_teams(term text, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_user_teams(term text, given_userid uuid) TO service_role;


--
-- Name: FUNCTION search_user_threads(term text, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_user_threads(term text, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_user_threads(term text, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_user_threads(term text, given_userid uuid) TO service_role;


--
-- Name: FUNCTION search_user_work_file(term text, given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_user_work_file(term text, given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.search_user_work_file(term text, given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.search_user_work_file(term text, given_userid uuid) TO service_role;


--
-- Name: FUNCTION set_user_all_notification_seen(given_userid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_user_all_notification_seen(given_userid uuid) TO anon;
GRANT ALL ON FUNCTION public.set_user_all_notification_seen(given_userid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.set_user_all_notification_seen(given_userid uuid) TO service_role;


--
-- Name: FUNCTION set_user_notification_seen(given_userid uuid, given_notificationid uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_user_notification_seen(given_userid uuid, given_notificationid uuid) TO anon;
GRANT ALL ON FUNCTION public.set_user_notification_seen(given_userid uuid, given_notificationid uuid) TO authenticated;
GRANT ALL ON FUNCTION public.set_user_notification_seen(given_userid uuid, given_notificationid uuid) TO service_role;


--
-- Name: FUNCTION extension(name text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.extension(name text) TO anon;
GRANT ALL ON FUNCTION storage.extension(name text) TO authenticated;
GRANT ALL ON FUNCTION storage.extension(name text) TO service_role;
GRANT ALL ON FUNCTION storage.extension(name text) TO dashboard_user;
GRANT ALL ON FUNCTION storage.extension(name text) TO postgres;


--
-- Name: FUNCTION filename(name text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.filename(name text) TO anon;
GRANT ALL ON FUNCTION storage.filename(name text) TO authenticated;
GRANT ALL ON FUNCTION storage.filename(name text) TO service_role;
GRANT ALL ON FUNCTION storage.filename(name text) TO dashboard_user;
GRANT ALL ON FUNCTION storage.filename(name text) TO postgres;


--
-- Name: FUNCTION foldername(name text); Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON FUNCTION storage.foldername(name text) TO anon;
GRANT ALL ON FUNCTION storage.foldername(name text) TO authenticated;
GRANT ALL ON FUNCTION storage.foldername(name text) TO service_role;
GRANT ALL ON FUNCTION storage.foldername(name text) TO dashboard_user;
GRANT ALL ON FUNCTION storage.foldername(name text) TO postgres;


--
-- Name: TABLE file_at_org; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.file_at_org TO anon;
GRANT ALL ON TABLE public.file_at_org TO authenticated;
GRANT ALL ON TABLE public.file_at_org TO service_role;


--
-- Name: TABLE file_at_team; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.file_at_team TO anon;
GRANT ALL ON TABLE public.file_at_team TO authenticated;
GRANT ALL ON TABLE public.file_at_team TO service_role;


--
-- Name: TABLE file_at_thread; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.file_at_thread TO anon;
GRANT ALL ON TABLE public.file_at_thread TO authenticated;
GRANT ALL ON TABLE public.file_at_thread TO service_role;


--
-- Name: TABLE file_history; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.file_history TO anon;
GRANT ALL ON TABLE public.file_history TO authenticated;
GRANT ALL ON TABLE public.file_history TO service_role;


--
-- Name: TABLE file_notes_signatures; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.file_notes_signatures TO anon;
GRANT ALL ON TABLE public.file_notes_signatures TO authenticated;
GRANT ALL ON TABLE public.file_notes_signatures TO service_role;


--
-- Name: TABLE forum_posts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.forum_posts TO anon;
GRANT ALL ON TABLE public.forum_posts TO authenticated;
GRANT ALL ON TABLE public.forum_posts TO service_role;


--
-- Name: TABLE forums; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.forums TO anon;
GRANT ALL ON TABLE public.forums TO authenticated;
GRANT ALL ON TABLE public.forums TO service_role;


--
-- Name: TABLE live_notifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.live_notifications TO anon;
GRANT ALL ON TABLE public.live_notifications TO authenticated;
GRANT ALL ON TABLE public.live_notifications TO service_role;


--
-- Name: TABLE notices; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.notices TO anon;
GRANT ALL ON TABLE public.notices TO authenticated;
GRANT ALL ON TABLE public.notices TO service_role;


--
-- Name: TABLE organizations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.organizations TO anon;
GRANT ALL ON TABLE public.organizations TO authenticated;
GRANT ALL ON TABLE public.organizations TO service_role;


--
-- Name: TABLE teams; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.teams TO anon;
GRANT ALL ON TABLE public.teams TO authenticated;
GRANT ALL ON TABLE public.teams TO service_role;


--
-- Name: TABLE thread_at_team; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.thread_at_team TO anon;
GRANT ALL ON TABLE public.thread_at_team TO authenticated;
GRANT ALL ON TABLE public.thread_at_team TO service_role;


--
-- Name: TABLE threads; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.threads TO anon;
GRANT ALL ON TABLE public.threads TO authenticated;
GRANT ALL ON TABLE public.threads TO service_role;


--
-- Name: TABLE user_at_orgs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_at_orgs TO anon;
GRANT ALL ON TABLE public.user_at_orgs TO authenticated;
GRANT ALL ON TABLE public.user_at_orgs TO service_role;


--
-- Name: TABLE user_at_teams; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_at_teams TO anon;
GRANT ALL ON TABLE public.user_at_teams TO authenticated;
GRANT ALL ON TABLE public.user_at_teams TO service_role;


--
-- Name: TABLE user_at_threads; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_at_threads TO anon;
GRANT ALL ON TABLE public.user_at_threads TO authenticated;
GRANT ALL ON TABLE public.user_at_threads TO service_role;


--
-- Name: TABLE user_devices; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_devices TO anon;
GRANT ALL ON TABLE public.user_devices TO authenticated;
GRANT ALL ON TABLE public.user_devices TO service_role;


--
-- Name: TABLE user_notices_list; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_notices_list TO anon;
GRANT ALL ON TABLE public.user_notices_list TO authenticated;
GRANT ALL ON TABLE public.user_notices_list TO service_role;


--
-- Name: TABLE user_publickey_history; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_publickey_history TO anon;
GRANT ALL ON TABLE public.user_publickey_history TO authenticated;
GRANT ALL ON TABLE public.user_publickey_history TO service_role;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO postgres;


--
-- Name: TABLE migrations; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.migrations TO anon;
GRANT ALL ON TABLE storage.migrations TO authenticated;
GRANT ALL ON TABLE storage.migrations TO service_role;
GRANT ALL ON TABLE storage.migrations TO postgres;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO postgres;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES  TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS  TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES  TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS  TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES  TO service_role;


--
-- PostgreSQL database dump complete
--

